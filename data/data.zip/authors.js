var AUTHORS =
{
  "AUTHORS":[
    {
      "pk_tbl_AUTHORS":"530",
      "s_REAL_NAME":"- dokument",
      "s_REAL_NAME_REVERS":"dokument -",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"524",
      "s_REAL_NAME":"– press",
      "s_REAL_NAME_REVERS":"press –",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Tiskové zprávy jsou publikovány bez redakčních zásahů a za jejich objektivitu redakce České školy nezodpovídá.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"519",
      "s_REAL_NAME":" INZERCE",
      "s_REAL_NAME_REVERS":"INZERCE",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"401",
      "s_REAL_NAME":"ACADEMIA _",
      "s_REAL_NAME_REVERS":"_ ACADEMIA",
      "s_EMAIL":"bejcek@c-agency.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"862",
      "s_REAL_NAME":"AIA",
      "s_REAL_NAME_REVERS":"AIA",
      "s_EMAIL":"aia@dzs.cz",
      "t_DESCRIPTION":"Akademická informační agentura, Dům zahraničních služeb MŠMT",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"697",
      "s_REAL_NAME":"AISIS",
      "s_REAL_NAME_REVERS":"AISIS",
      "s_EMAIL":"freinet@aisis.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"445",
      "s_REAL_NAME":"AP, ČTK redakce\/",
      "s_REAL_NAME_REVERS":"AP, ČTK redakce\/",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"692",
      "s_REAL_NAME":"Astová Jana",
      "s_REAL_NAME_REVERS":"Jana Astová",
      "s_EMAIL":"johankark@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"615",
      "s_REAL_NAME":"Báča Milan",
      "s_REAL_NAME_REVERS":"Milan Báča",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"591",
      "s_REAL_NAME":"Baier Jan",
      "s_REAL_NAME_REVERS":"Jan Baier",
      "s_EMAIL":"janbaier@centrum.cz",
      "t_DESCRIPTION":"Autor je učitelem na prvním stupni základní školy.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"920",
      "s_REAL_NAME":"Bála Rostislav",
      "s_REAL_NAME_REVERS":"Rostislav Bála",
      "s_EMAIL":"rostislav.bala@centrum.cz",
      "t_DESCRIPTION":"ZŠ Opavská 22 ve Vítkově",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"589",
      "s_REAL_NAME":"Balada Milan",
      "s_REAL_NAME_REVERS":"Milan Balada",
      "s_EMAIL":"balada.milan@quick.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"797",
      "s_REAL_NAME":"Baladová, Gabriela ",
      "s_REAL_NAME_REVERS":"Gabriela Baladová,",
      "s_EMAIL":"baladova@vuppraha.cz",
      "t_DESCRIPTION":"Pracovnice VÚP v Praze, oddělení jazykového a společenskovědního vzdělávání a umění a kultury",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"916",
      "s_REAL_NAME":"Balvín Jaroslav ",
      "s_REAL_NAME_REVERS":"Jaroslav Balvín",
      "s_EMAIL":"jbalvin@ukf.sk",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"661",
      "s_REAL_NAME":"Bartoš Walter",
      "s_REAL_NAME_REVERS":"Walter Bartoš",
      "s_EMAIL":"bartos@psp.cz",
      "t_DESCRIPTION":"Autor je předsedou školského výboru Sněmovny Parlamentu ČR a stínovým ministrem školství ODS.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"33",
      "s_REAL_NAME":"Bartošová Romana",
      "s_REAL_NAME_REVERS":"Romana Bartošová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"924",
      "s_REAL_NAME":"Bartošová, Jana",
      "s_REAL_NAME_REVERS":"Jana Bartošová,",
      "s_EMAIL":"pedagog@pmjak.cz",
      "t_DESCRIPTION":"Pedagogické muzeum J. A. Komenského v Praze",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"881",
      "s_REAL_NAME":"Bártová, Eliška ",
      "s_REAL_NAME_REVERS":"Eliška Bártová,",
      "s_EMAIL":"eliska.bartova@aktualne.cz",
      "t_DESCRIPTION":"Během studií na vysoké škole začala pracovat v týdeníku Respekt. Na začátku loňského roku z něj po pěti letech odešla kvůli napjaté situaci v redakci, ve které už nebylo možné se dále rozvíjet a tvořit.\n\nV Respektu se zabývala především sociální tématikou, často psala o školství, zdravotnictví, popisovala korupční kauzy, připravovala reportáže o životě běžných lidí.\n\nV deníku Aktuálně.cz se věnuje podobným tématům.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"865",
      "s_REAL_NAME":"Basl, Josef",
      "s_REAL_NAME_REVERS":"Josef Basl,",
      "s_EMAIL":"basljo@centrum.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"635",
      "s_REAL_NAME":"Bavorová Kateřina",
      "s_REAL_NAME_REVERS":"Kateřina Bavorová",
      "s_EMAIL":"katerina.bavorova@eun.org",
      "t_DESCRIPTION":"Autorka je pedagogická koordinátorka akce Spring Day in Europe v ČR. ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"880",
      "s_REAL_NAME":"Bečvář, Jindřich",
      "s_REAL_NAME_REVERS":"Jindřich Bečvář,",
      "s_EMAIL":"becvar@karlin.mff.cuni.cz",
      "t_DESCRIPTION":"Katedra didaktiky matematiky MFF UK ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"807",
      "s_REAL_NAME":"Bečvářová, Zuzana ",
      "s_REAL_NAME_REVERS":"Zuzana Bečvářová,",
      "s_EMAIL":"jan.wagner@cpress.cz",
      "t_DESCRIPTION":"ČŠI Praha",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"703",
      "s_REAL_NAME":"Bednaříková Iveta",
      "s_REAL_NAME_REVERS":"Iveta Bednaříková",
      "s_EMAIL":"bednari@pdfnw.upol.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"447",
      "s_REAL_NAME":"Belej Vincent",
      "s_REAL_NAME_REVERS":"Vincent Belej",
      "s_EMAIL":"vincent.belej@cpress.cz",
      "t_DESCRIPTION":"Vincent Belej je redaktorem časopisu Computer.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"636",
      "s_REAL_NAME":"Bělík Václav ",
      "s_REAL_NAME_REVERS":"Václav Bělík",
      "s_EMAIL":"Vaclav.Belik@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"35",
      "s_REAL_NAME":"Bělohoubek Ivo",
      "s_REAL_NAME_REVERS":"Ivo Bělohoubek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"473",
      "s_REAL_NAME":"Bendl Stanislav",
      "s_REAL_NAME_REVERS":"Stanislav Bendl",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"801",
      "s_REAL_NAME":"Beňuška, Jozef",
      "s_REAL_NAME_REVERS":"Jozef Beňuška,",
      "s_EMAIL":"jbenuska@nextra.sk",
      "t_DESCRIPTION":"Gymnázium Viliama Paulinyho-Tótha, Malá hora 3, 03601 Martin, Slovensko, http:\/\/www.gymmt.sk\/~benuska ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"486",
      "s_REAL_NAME":"Beránek Josef",
      "s_REAL_NAME_REVERS":"Josef Beránek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"606",
      "s_REAL_NAME":"Beranová Jaroslava",
      "s_REAL_NAME_REVERS":"Jaroslava Beranová",
      "s_EMAIL":"8zs@ali.pb.cz",
      "t_DESCRIPTION":"Autorka působí na 8. základní škole v Příbrami.   \n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"481",
      "s_REAL_NAME":"Berka Vít",
      "s_REAL_NAME_REVERS":"Vít Berka",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Mgr. ing. Vít Berka je vedoucí ekonomicko-právního oddělení  Českomoravského odborového svazu pracovníků ve školství.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"631",
      "s_REAL_NAME":"Bernard Zdeněk",
      "s_REAL_NAME_REVERS":"Zdeněk Bernard",
      "s_EMAIL":"Pavla.Bednarova@msmt.cz",
      "t_DESCRIPTION":"Ing. Zdeněk Bernard je vrchním ředitelem ekonomické sekce MŠMT.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"422",
      "s_REAL_NAME":"Bínová Silvie",
      "s_REAL_NAME_REVERS":"Silvie Bínová",
      "s_EMAIL":"sbinova@yahoo.com",
      "t_DESCRIPTION":"Autorka je spolupracovnicí Českého rozhlasu.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"906",
      "s_REAL_NAME":"Biskupová, Veronika",
      "s_REAL_NAME_REVERS":"Veronika Biskupová,",
      "s_EMAIL":"biskve@atlas.cz",
      "t_DESCRIPTION":"Základní škola a mateřská škola, Kravsko, příspěvková organizace, Kravsko 169, 671 51 Kravsko; Tel.: 515 255 124",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"506",
      "s_REAL_NAME":"Bittnerová Dana",
      "s_REAL_NAME_REVERS":"Dana Bittnerová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"700",
      "s_REAL_NAME":"Bjačková Alena",
      "s_REAL_NAME_REVERS":"Alena Bjačková",
      "s_EMAIL":"bjackova@pcpraha.cz",
      "t_DESCRIPTION":"Autorka je pracovnicí Pedagogického centra Praha.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"651",
      "s_REAL_NAME":"Blažek Bohuslav",
      "s_REAL_NAME_REVERS":"Bohuslav Blažek",
      "s_EMAIL":"animator@hrad.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"710",
      "s_REAL_NAME":"Blažek Filip",
      "s_REAL_NAME_REVERS":"Filip Blažek",
      "s_EMAIL":"filip@designiq.cz",
      "t_DESCRIPTION":"Grafickým designem se živí od roku 1993. V roce 2000 absolvoval studium na Filosofické fakultě University Karlovy v Praze diplomovu prací na téma Česká společnost a grafický design ve 20. století. Kromě práce designéra ve vlastním studiu Designiq je také spoluautorem publikace Praktická typografie (ComputerPress, 2000, 2004), pravidelně přispívá do odborných periodik. Je zakladatelem a členem redakčního týmu časopisu Typo, zabývajícího se typografií, grafickým designem a vizuální komunikací. Je provozovatelem webového portálu Typo.cz věnovaného českému i světovému grafickému designu.\nOd roku 1999 připravuje pro odbornou veřejnost přednášky na téma písmo a corporate identity (Praha 1999-2005, Zlín 2003, Berlin 2004, Beirut 2005).\nVyučuje typografii na Institutu digitálních médií. Je českým delegátem mezinárodní typografické organizace ATypI. ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"576",
      "s_REAL_NAME":"BMI ",
      "s_REAL_NAME_REVERS":"BMI",
      "s_EMAIL":"bmi@brezen.cz",
      "t_DESCRIPTION":"Autorem zprávy je sdružení BMI – pořadatel projektu Březen – měsíc Internetu.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"52",
      "s_REAL_NAME":"Boček Libor",
      "s_REAL_NAME_REVERS":"Libor Boček",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"823",
      "s_REAL_NAME":"Boňková,Jana ",
      "s_REAL_NAME_REVERS":"Boňková,Jana",
      "s_EMAIL":"bonkova@vuppraha.cz",
      "t_DESCRIPTION":"Výzkumný ústav pedagogický v Praze, oddělení jazykového a společenskovědního vzdělávání a umění a kultury, koncepce a obsah vzdělávání společenskovědních oborů ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"896",
      "s_REAL_NAME":"Botek, Zdeněk ",
      "s_REAL_NAME_REVERS":"Zdeněk Botek,",
      "s_EMAIL":"botek@guh.cz",
      "t_DESCRIPTION":"Ředitel Gymnázia Uherské Hradiště",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"809",
      "s_REAL_NAME":"Brant, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Brant,",
      "s_EMAIL":"brant@vuppraha.cz",
      "t_DESCRIPTION":"Výzkumný ústav pedagogický v Praze \nKoncepce a obsah vzdělávání v matematice na ZŠ\nKoncepce a obsah vzdělávání v oblasti Člověk a svět práce na ZŠ ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"16",
      "s_REAL_NAME":"Brdička Bořivoj",
      "s_REAL_NAME_REVERS":"Bořivoj Brdička",
      "s_EMAIL":"bobr@cesnet.cz",
      "t_DESCRIPTION":"Ing. Bořivoj Brdička, Ph.D. působí na Katedře informačních technologií a technické výchovy (<a href=\"http:\/\/it.pedf.cuni.cz\/\" target=\"_blank\" style=\"color: rgb(42, 93, 176); \">http:\/\/it.pedf.cuni.cz\/<\/a>) UK PedF v Praze, kde má na starosti portál Učitelský spomocník (<a href=\"http:\/\/www.spomocnik.cz\/\" target=\"_blank\" style=\"color: rgb(42, 93, 176); \">http:\/\/www.spomocnik.cz\/<\/a>).",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"940",
      "s_REAL_NAME":"Bregant, Michal",
      "s_REAL_NAME_REVERS":"Michal Bregant,",
      "s_EMAIL":"bregant@famu.cz",
      "t_DESCRIPTION":"Teoretik a historik filmu, děkan FAMU.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"715",
      "s_REAL_NAME":"Břehovská Marta",
      "s_REAL_NAME_REVERS":"Marta Břehovská",
      "s_EMAIL":"marta.brehovska@zs1.kraslice.indos.cz ",
      "t_DESCRIPTION":"Základní škola Kraslice, Havlíčkova 1717, 358 01 Kraslice, tel: 352 686 518",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"670",
      "s_REAL_NAME":"Brom Zdeněk",
      "s_REAL_NAME_REVERS":"Zdeněk Brom",
      "s_EMAIL":"zdenek.brom@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"981",
      "s_REAL_NAME":"Brousil, Tomáš",
      "s_REAL_NAME_REVERS":"Tomáš Brousil,",
      "s_EMAIL":"mail@suitcasetype.com",
      "t_DESCRIPTION":"* 13. 5. 1975 v Nitře. Původně mechanik a opravář letadel. V roce 1998 absolvoval Střední mistrovskou školu uměleckého designu v Praze, od roku 2002 studuje na VŠUP v Praze (ateliér písma a typografie). Věnuje se grafickému designu v kulturní oblasti, především pro divadelní projekty. V roce 2003 založil písmolijnu Suitcase Type Foundry. Účastnil se mezinárodních výstav a projektů zaměřených na písmo (e-a-t, Bookmarks). V roce 2005 obdržel cenu Vynikající studentský design od Design centra ČR za vizuální styl divadla Rokoko, laureát Velké ceny brněnského Bienále grafického designu 2008, držitel TDC Certificate of Excellence in Type Design 2008. V současnosti pracuje jako asistent atelieru Tvorba písma a typografie na VŠUP. www.suitcasetype.com",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"553",
      "s_REAL_NAME":"Brož František",
      "s_REAL_NAME_REVERS":"František Brož",
      "s_EMAIL":"broz@cermat.cz",
      "t_DESCRIPTION":"koordinátor pro český jazyk a literaturu\nCERMAT\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"639",
      "s_REAL_NAME":"Brož Milan ",
      "s_REAL_NAME_REVERS":"Milan Brož",
      "s_EMAIL":"mibroz@mbox.vol.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"497",
      "s_REAL_NAME":"Broža Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Broža",
      "s_EMAIL":"j.broza@seznam.cz",
      "t_DESCRIPTION":"Autor působí na základní škole.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"603",
      "s_REAL_NAME":"Brožová Věra",
      "s_REAL_NAME_REVERS":"Věra Brožová",
      "s_EMAIL":"redakce@ucitelske-listy.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"409",
      "s_REAL_NAME":"Bubeníček Petr",
      "s_REAL_NAME_REVERS":"Petr Bubeníček",
      "s_EMAIL":"petr.bubenicek@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"788",
      "s_REAL_NAME":"Búr, Viliam ",
      "s_REAL_NAME_REVERS":"Viliam Búr,",
      "s_EMAIL":"bur@gmail.com",
      "t_DESCRIPTION":"Programátor, aktivista, zvědavý a přemýšlející člověk.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"773",
      "s_REAL_NAME":"Buryánek, Jan",
      "s_REAL_NAME_REVERS":"Jan Buryánek,",
      "s_EMAIL":"ceskaskola@cpress.cz",
      "t_DESCRIPTION":"Koordinátor modulu Střední školství",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"815",
      "s_REAL_NAME":"Cakl, Ondřej",
      "s_REAL_NAME_REVERS":"Ondřej Cakl,",
      "s_EMAIL":"o.cakl@prodos-cz.cz",
      "t_DESCRIPTION":"Redaktor pedagogického nakladatelství PRODOS spol. s r. o.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"624",
      "s_REAL_NAME":"Canov Michael ",
      "s_REAL_NAME_REVERS":"Michael Canov",
      "s_EMAIL":"canovm@raz-dva.cz",
      "t_DESCRIPTION":"Ing. Michael Canov je gymnaziálním pedagogem (Ch, F, M) a starostou města Chrastava, dříve působil na ŽŠ.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"814",
      "s_REAL_NAME":"Cardová, Jitka",
      "s_REAL_NAME_REVERS":"Jitka Cardová,",
      "s_EMAIL":"j.cardova@prodos-cz.cz",
      "t_DESCRIPTION":"Redaktor pedagogického nakladatelství PRODOS spol. s r. o.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"779",
      "s_REAL_NAME":"Carneiro, Roberto ",
      "s_REAL_NAME_REVERS":"Roberto Carneiro,",
      "s_EMAIL":"rc@cepcep.ucp.pt",
      "t_DESCRIPTION":"Pracuje v Institutu distančního vzdělávání portugalské Catholic University (<A HREF=\"http:\/\/www.elearningeuropa.info\/index.php?page=doc&amp;doc_id=7017&amp;doclng=6\">biografie<\/A>)",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"678",
      "s_REAL_NAME":"Čechová Barbara",
      "s_REAL_NAME_REVERS":"Barbara Čechová",
      "s_EMAIL":"cechova@studentin.cz",
      "t_DESCRIPTION":"Autorka je šéfredaktorkou časopisu StudentIN.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"36",
      "s_REAL_NAME":"Čechovský Marek",
      "s_REAL_NAME_REVERS":"Marek Čechovský",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"955",
      "s_REAL_NAME":"Čermák, Miloš",
      "s_REAL_NAME_REVERS":"Miloš Čermák,",
      "s_EMAIL":"cermak@extra.cz",
      "t_DESCRIPTION":"Novinář. Mediální expert. Bývalý redaktor časopisu Reflex (1991 - 2003, 2005-2006) a šéfkomentátor Lidových novin (2003 - 2005).",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"767",
      "s_REAL_NAME":"CERMAT",
      "s_REAL_NAME_REVERS":"CERMAT",
      "s_EMAIL":"info@cermat.cz",
      "t_DESCRIPTION":"Centrum pro zjišťování výsledků vzdělávání",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"597",
      "s_REAL_NAME":"Černá Markéta",
      "s_REAL_NAME_REVERS":"Markéta Černá",
      "s_EMAIL":"marketa.cerna@uvrs.pedf.cuni.cz",
      "t_DESCRIPTION":"Autorka působí v ÚVRŠ PedF UK Praha.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"456",
      "s_REAL_NAME":"Černochová Miroslava",
      "s_REAL_NAME_REVERS":"Miroslava Černochová",
      "s_EMAIL":"miroslava.cernochova@pedf.cuni.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"671",
      "s_REAL_NAME":"Černý Michal",
      "s_REAL_NAME_REVERS":"Michal Černý",
      "s_EMAIL":"cerny@zs-kl.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"682",
      "s_REAL_NAME":"Černý Radek",
      "s_REAL_NAME_REVERS":"Radek Černý",
      "s_EMAIL":"rad.cerny@centrum.cz",
      "t_DESCRIPTION":"Autor je studentem Pedagogické fakulty Jihočeské univerzity.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"627",
      "s_REAL_NAME":"Červenka Stanislav",
      "s_REAL_NAME_REVERS":"Stanislav Červenka",
      "s_EMAIL":"stanislav.cervenka@seznam.cz",
      "t_DESCRIPTION":"Autor působí na ZŠ Mileč.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"857",
      "s_REAL_NAME":"Čevela, Lubomír ",
      "s_REAL_NAME_REVERS":"Lubomír Čevela,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"54",
      "s_REAL_NAME":"Chlebek Petr",
      "s_REAL_NAME_REVERS":"Petr Chlebek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"843",
      "s_REAL_NAME":"Chlíbková Daniela",
      "s_REAL_NAME_REVERS":"Daniela Chlíbková",
      "s_EMAIL":"Daniela.chlibkova@quick.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"849",
      "s_REAL_NAME":"Chromý, Jan",
      "s_REAL_NAME_REVERS":"Jan Chromý,",
      "s_EMAIL":"redakce@ikaros.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"492",
      "s_REAL_NAME":"Chvátalová Helena",
      "s_REAL_NAME_REVERS":"Helena Chvátalová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"514",
      "s_REAL_NAME":"Chvojka Jiří",
      "s_REAL_NAME_REVERS":"Jiří Chvojka",
      "s_EMAIL":"jiri.chvojka@acol.cz",
      "t_DESCRIPTION":"Autor je tiskovým mluvčím společnosti AutoCont On Line.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"681",
      "s_REAL_NAME":"Cichoňová Iva",
      "s_REAL_NAME_REVERS":"Iva Cichoňová",
      "s_EMAIL":"info@zsangel.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"848",
      "s_REAL_NAME":"Cikánková, Jarmila",
      "s_REAL_NAME_REVERS":"Jarmila Cikánková,",
      "s_EMAIL":"redakce@ikaros.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"436",
      "s_REAL_NAME":"Cimlerová Pavla",
      "s_REAL_NAME_REVERS":"Pavla Cimlerová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"PhDr. Pavla Cimlerová je ředitelkou\nPedagogicko-psychologické poradny v Mělníku.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"656",
      "s_REAL_NAME":"Činčera Jan",
      "s_REAL_NAME_REVERS":"Jan Činčera",
      "s_EMAIL":"jan.cincera@vslib.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"721",
      "s_REAL_NAME":"Čipera, Jan ",
      "s_REAL_NAME_REVERS":"Jan Čipera,",
      "s_EMAIL":"cipera@natur.cuni.cz ",
      "t_DESCRIPTION":"Přírodovědecká fakulta UK Praha",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"561",
      "s_REAL_NAME":"Čížek Petr ",
      "s_REAL_NAME_REVERS":"Petr Čížek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"autor časopisu Computer",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"977",
      "s_REAL_NAME":"Čížek, Jakub",
      "s_REAL_NAME_REVERS":"Jakub Čížek,",
      "s_EMAIL":"jakub.cizek@cpress.cz",
      "t_DESCRIPTION":"Redaktor časopisu Computer a Zive.cz.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"594",
      "s_REAL_NAME":"článek PR",
      "s_REAL_NAME_REVERS":"PR článek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"875",
      "s_REAL_NAME":"Cogoi, Cristina ",
      "s_REAL_NAME_REVERS":"Cristina Cogoi,",
      "s_EMAIL":"cristina.cogoi@aster.it",
      "t_DESCRIPTION":"konzultant ASTER S. Cons. p. a.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"395",
      "s_REAL_NAME":"Computer  ",
      "s_REAL_NAME_REVERS":"  Computer",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Computer (*1994), osvědčený průvodce v džungli počítačových technologií. Computer je počítačový čtrnáctideník, který vychází již sedmým rokem a píše fundovaně, ale zároveň jasně, srozumitelně a čtivě o dění v oboru počítačů.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"53",
      "s_REAL_NAME":"Csapkova Irena",
      "s_REAL_NAME_REVERS":"Irena Csapkova",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"892",
      "s_REAL_NAME":"ČŠI",
      "s_REAL_NAME_REVERS":"ČŠI",
      "s_EMAIL":"posta@csicr.cz",
      "t_DESCRIPTION":"Česká školní inspekce",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"380",
      "s_REAL_NAME":"čtenář <!>",
      "s_REAL_NAME_REVERS":"<!> čtenář",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"577",
      "s_REAL_NAME":"ČTK   ",
      "s_REAL_NAME_REVERS":"ČTK",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Materiál České tiskové kanceláře.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"448",
      "s_REAL_NAME":"ČTK redakce\/",
      "s_REAL_NAME_REVERS":"redakce\/ ČTK",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"411",
      "s_REAL_NAME":"ČTK Reuters\/",
      "s_REAL_NAME_REVERS":"Reuters\/ ČTK",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"471",
      "s_REAL_NAME":"ČTK Vít Šebor \/",
      "s_REAL_NAME_REVERS":"ČTK Vít Šebor \/",
      "s_EMAIL":"vit.sebor@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"41",
      "s_REAL_NAME":"ČTK Zpravodajství",
      "s_REAL_NAME_REVERS":"Zpravodajství ČTK",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"549",
      "s_REAL_NAME":"ČTK\/AFP",
      "s_REAL_NAME_REVERS":"ČTK\/AFP",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"28",
      "s_REAL_NAME":"Čulík Jan",
      "s_REAL_NAME_REVERS":"Jan Čulík",
      "s_EMAIL":"ceskaskola@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"831",
      "s_REAL_NAME":"CZ.RVP",
      "s_REAL_NAME_REVERS":"CZ.RVP",
      "s_EMAIL":"editor@rvp.cz",
      "t_DESCRIPTION":"Z portálu RVP.CZ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"904",
      "s_REAL_NAME":"CZESHA Unie",
      "s_REAL_NAME_REVERS":"Unie CZESHA",
      "s_EMAIL":"info@czesha.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"393",
      "s_REAL_NAME":"D Lu",
      "s_REAL_NAME_REVERS":"Lu D",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"523",
      "s_REAL_NAME":"Dana Rabiňáková Marek Mičienka,",
      "s_REAL_NAME_REVERS":"Dana Rabiňáková Marek Mičienka,",
      "s_EMAIL":"micienka@cermat.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"515",
      "s_REAL_NAME":"Dana Šlancarová",
      "s_REAL_NAME_REVERS":"Šlancarová Dana",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"586",
      "s_REAL_NAME":"Dančáková Jana",
      "s_REAL_NAME_REVERS":"Jana Dančáková",
      "s_EMAIL":"jana.dancakova@centrum.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"941",
      "s_REAL_NAME":"dědinsky, Kantor",
      "s_REAL_NAME_REVERS":"Kantor dědinsky,",
      "s_EMAIL":"kantor.bloguje@seznam.cz",
      "t_DESCRIPTION":"Tuž jak bych to napisal, aby to bylo pravdive a nikoho sem přitom něurazil...\n\nNaša dědinska škola neni ani mala, ani velka, taka středni bych pravil. Ale kur je tu vpysk. Eště, že neni škola větši, bo by to byla hotova chovatelska stanica. Tež děcka tu jakesi chodi, ale ty su fajne, akorat někere smrdi.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"994",
      "s_REAL_NAME":"Dobšík, František",
      "s_REAL_NAME_REVERS":"František Dobšík,",
      "s_EMAIL":"dobsik.frantisek@cmkos.cz",
      "t_DESCRIPTION":"Předseda ČMOS PŠ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"649",
      "s_REAL_NAME":"Dobšíková Eva ",
      "s_REAL_NAME_REVERS":"Eva Dobšíková",
      "s_EMAIL":"evadobsikova@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"799",
      "s_REAL_NAME":"Dočekal, Daniel",
      "s_REAL_NAME_REVERS":"Daniel Dočekal,",
      "s_EMAIL":"info@stic.cz",
      "t_DESCRIPTION":"Centrum moderních technologií ve škole (School Technology Innovation Center)",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"725",
      "s_REAL_NAME":"Dolanská, Miluše",
      "s_REAL_NAME_REVERS":"Miluše Dolanská,",
      "s_EMAIL":"miluse.dolanska@arcdata.cz ",
      "t_DESCRIPTION":"ARCDATA PRAHA, s.r.o., Hybernská 24, 110 00 Praha 1",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"385",
      "s_REAL_NAME":"Dolejší Karel",
      "s_REAL_NAME_REVERS":"Karel Dolejší",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"937",
      "s_REAL_NAME":"Dolejší, Irena",
      "s_REAL_NAME_REVERS":"Irena Dolejší,",
      "s_EMAIL":"dolejsi.irena@ujak.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"648",
      "s_REAL_NAME":"Doležel Michal",
      "s_REAL_NAME_REVERS":"Michal Doležel",
      "s_EMAIL":"computer@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"529",
      "s_REAL_NAME":"Dolinský Jiří",
      "s_REAL_NAME_REVERS":"Jiří Dolinský",
      "s_EMAIL":"j.dolinsky.st@atlas.cz",
      "t_DESCRIPTION":"Autor je zástupce ředitele ZŠ Bojkovice.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"985",
      "s_REAL_NAME":"Dömischová, Ivona ",
      "s_REAL_NAME_REVERS":"Ivona Dömischová,",
      "s_EMAIL":"ivona.domischova@seznam.cz",
      "t_DESCRIPTION":"PdF UP Olomouc, katedra německého jazyka\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"756",
      "s_REAL_NAME":"Dostál,  Jiří PaedDr. PhDr.",
      "s_REAL_NAME_REVERS":"Dostál, Jiří PaedDr. PhDr.",
      "s_EMAIL":"dos003@seznam.cz",
      "t_DESCRIPTION":"Katedra technické a informační výchovy Pedagogické fakulty Univerzity Palackého v Olomouci.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"665",
      "s_REAL_NAME":"DPA\/ČTK",
      "s_REAL_NAME_REVERS":"DPA\/ČTK",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"458",
      "s_REAL_NAME":"Dračková Martina",
      "s_REAL_NAME_REVERS":"Martina Dračková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"39",
      "s_REAL_NAME":"Drahoš Petr",
      "s_REAL_NAME_REVERS":"Petr Drahoš",
      "s_EMAIL":"drahos@ceskaskola.cz",
      "t_DESCRIPTION":"Petr Drahoš (*1972) vystudoval gymnázium v Hlinsku. Zkušenosti s českým školstvím dále sbíral na FJFI ČVUT, VŠE a FFUK (obor pedagogika). V současnosti se aktivně zajímá o reformu školství i celé společnosti.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"387",
      "s_REAL_NAME":"Drinocká Hana",
      "s_REAL_NAME_REVERS":"Hana Drinocká",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"860",
      "s_REAL_NAME":"Drtík, Aleš ",
      "s_REAL_NAME_REVERS":"Aleš Drtík,",
      "s_EMAIL":"aldrtik@post.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"507",
      "s_REAL_NAME":"Duhajský Josef",
      "s_REAL_NAME_REVERS":"Josef Duhajský",
      "s_EMAIL":"josef.duhajsky@gbl.cz",
      "t_DESCRIPTION":"Autor je pedagogem na Gymnáziu J. S. Machara v Brandýse nad Labem - Staré Boleslavi.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"949",
      "s_REAL_NAME":"Duženkov, Vladimír",
      "s_REAL_NAME_REVERS":"Vladimír Duženkov,",
      "s_EMAIL":"zs-tynec@cmail.cz",
      "t_DESCRIPTION":"Autor je ředitelem Základní školy v Panenském Týnci.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"399",
      "s_REAL_NAME":"Dvoř´áková Barbora",
      "s_REAL_NAME_REVERS":"Barbora Dvoř´áková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"693",
      "s_REAL_NAME":"Dvořák Dominik",
      "s_REAL_NAME_REVERS":"Dominik Dvořák",
      "s_EMAIL":"naklad@portal.cz",
      "t_DESCRIPTION":"RNDr. Dominik Dvořák je odborný redaktor pedagogických a psychologických publikací.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"582",
      "s_REAL_NAME":"Dvořák Martin",
      "s_REAL_NAME_REVERS":"Martin Dvořák",
      "s_EMAIL":"zdenek.dvorak@polna.cz",
      "t_DESCRIPTION":"Autor vyučuje na ZŠ Polná.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"558",
      "s_REAL_NAME":"Dvořák Milan ",
      "s_REAL_NAME_REVERS":"Milan Dvořák",
      "s_EMAIL":"milan.dvorak@zs.slapanov.indos.cz",
      "t_DESCRIPTION":"Autor je ředitelem základní školy.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"923",
      "s_REAL_NAME":"Dvořák, Jaromír ",
      "s_REAL_NAME_REVERS":"Jaromír Dvořák,",
      "s_EMAIL":"mgr.j.dvorak@tiscali.cz",
      "t_DESCRIPTION":"Středoškolský kantor, krajský zastupitel za SOS, člen Výboru pro školství a sport Zastupitelstva LK.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"392",
      "s_REAL_NAME":"Dvořáková Barbora",
      "s_REAL_NAME_REVERS":"Barbora Dvořáková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"438",
      "s_REAL_NAME":"Dvořáková Lenka",
      "s_REAL_NAME_REVERS":"Lenka Dvořáková",
      "s_EMAIL":"sborovna@volny.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"32",
      "s_REAL_NAME":"Eger Ludvík",
      "s_REAL_NAME_REVERS":"Ludvík Eger",
      "s_EMAIL":"ludvik.eger@fek.zcu.cz",
      "t_DESCRIPTION":"PaedDr. Ludvík EGER, CSc., (*1961)\nvystudoval Pedagogické fakultě v Ústí n. L., obor učitelství všeobecně vzdělávacích předmětů. Absolvoval kurz metodologie distančního a on-line studia na Heriot Watt University.\nPůsobil jako člen poradní komise MŠMT pro reformu státní správy v oblasti tělovýchovy a mládeže. V současné době pracje jako odborný asistent na ekonomické fakultě ZČU.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"962",
      "s_REAL_NAME":"Egerová, Dana",
      "s_REAL_NAME_REVERS":"Dana Egerová,",
      "s_EMAIL":"dana.egerova@email.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"988",
      "s_REAL_NAME":"Eichler, Patrik",
      "s_REAL_NAME_REVERS":"Patrik Eichler,",
      "s_EMAIL":"redakce@literarky.cz",
      "t_DESCRIPTION":"Autor je členem redakce Literárních novin. Rediguje rubriky Spor a Rozhovor.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"856",
      "s_REAL_NAME":"elearningeuropa.info",
      "s_REAL_NAME_REVERS":"elearningeuropa.info",
      "s_EMAIL":"info@elearningeuropa.inf",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"520",
      "s_REAL_NAME":"Eric Karulas Milan Hausner,",
      "s_REAL_NAME_REVERS":"Eric Karulas Milan Hausner,",
      "s_EMAIL":"hausner@lupacovka.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"899",
      "s_REAL_NAME":"Etrychová, Pavla ",
      "s_REAL_NAME_REVERS":"Pavla Etrychová,",
      "s_EMAIL":"petrychova@erudis.cz",
      "t_DESCRIPTION":"Vedoucí projektu Projektové vyučování, Erudis, o.p.s.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"925",
      "s_REAL_NAME":"eTwinning",
      "s_REAL_NAME_REVERS":"eTwinning",
      "s_EMAIL":"petr.chalus@naep.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"838",
      "s_REAL_NAME":"Eurydice",
      "s_REAL_NAME_REVERS":"Eurydice",
      "s_EMAIL":"info@eurydice.org",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"965",
      "s_REAL_NAME":"Eva Kaprálová",
      "s_REAL_NAME_REVERS":"Kaprálová Eva",
      "s_EMAIL":"kaprev@seznam.cz",
      "t_DESCRIPTION":"Ředitelka ZŠ a MŠ Běchary",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"423",
      "s_REAL_NAME":"Fadrný Jiří",
      "s_REAL_NAME_REVERS":"Jiří Fadrný",
      "s_EMAIL":"fadrny@cpress.cz",
      "t_DESCRIPTION":"Autor dotazů do Poradny",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"930",
      "s_REAL_NAME":"Faltýn, Jaroslav ",
      "s_REAL_NAME_REVERS":"Jaroslav Faltýn,",
      "s_EMAIL":"faltyn@vuppraha.cz",
      "t_DESCRIPTION":"Vedoucí oddělení Srovnávací pedagogika VÚP v Praze",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"764",
      "s_REAL_NAME":"Faltýnek Lukáš",
      "s_REAL_NAME_REVERS":"Lukáš Faltýnek",
      "s_EMAIL":"lukas.faltynek@seznam.cz",
      "t_DESCRIPTION":"Autor (*1974) absolvoval Univerzitu Hradec Králové, obor informační management. Pracuje jako analytik-programátor. Publikační činnosti se věnuje ve volných chvílích.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"38",
      "s_REAL_NAME":"Fencl Ivo",
      "s_REAL_NAME_REVERS":"Ivo Fencl",
      "s_EMAIL":"ifencl@mybox.cz",
      "t_DESCRIPTION":"PhDr. Ivo Fencl,CSc. (*1938),literární historik a kritik, publicista a esejista. Učitel na základních, středních a vysokých školách, naposledy byl členem katedry české literatury na PF UK v Praze, působil jako školní inspektor ČR pro speciální školstvi, od roku 2000 externi pedagog na UK. Pravidelně publikuje v literárních časopisech a některých denících. \n\nVydal knihu Vize a iluze skupiny Květen.\n \n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"413",
      "s_REAL_NAME":"Fencl Martin",
      "s_REAL_NAME_REVERS":"Martin Fencl",
      "s_EMAIL":"martin.fencl@seznam.cz",
      "t_DESCRIPTION":"Martinu Fenclovi je dvanáct let a ve svém věku napsal již řadu článků zveřejněných na několika internetových magazínech (Česká škola.cz, Živě.cz, eKamarád.cz apod.)",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"885",
      "s_REAL_NAME":"Ferguson, Marilyn ",
      "s_REAL_NAME_REVERS":"Marilyn Ferguson,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Americká spisovatelka a editorka Brain\/Mind Bulletin (od roku 1975).",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"753",
      "s_REAL_NAME":"Fialová, Lada",
      "s_REAL_NAME_REVERS":"Lada Fialová,",
      "s_EMAIL":"lafia@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"17",
      "s_REAL_NAME":"Fikker Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Fikker",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"430",
      "s_REAL_NAME":"Fišerová Vladimíra",
      "s_REAL_NAME_REVERS":"Vladimíra Fišerová",
      "s_EMAIL":"vedeni@altis.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"778",
      "s_REAL_NAME":"Fisher, Clarence ",
      "s_REAL_NAME_REVERS":"Clarence Fisher,",
      "s_EMAIL":"glassbeed@gmail.com",
      "t_DESCRIPTION":"Je učitelem matematiky, technických předmětů a francouzštiny 7. a 8. tříd na Joseph H. Kerr School v kanadské Manitobě. V&nbsp;posledním období mu byla\nudělena celá řada cen za příkladné využívání technologií ve výuce. O své zkušenosti a&nbsp;nápady se s&nbsp;kolegy dělí prostřednictvím blogu <A HREF=\"http:\/\/remoteaccess.typepad.com\/\">Remote Access<\/A>.",
      "s_PHOTO_NAME":"FisherClarence.jpg",
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"804",
      "s_REAL_NAME":"Fogl, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Fogl,",
      "s_EMAIL":"jiri.fogl@flyweb.cz",
      "t_DESCRIPTION":"<A HREF=\"http:\/\/www.eregon.eu\/\">http:\/\/www.eregon.eu\/<\/A>",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"51",
      "s_REAL_NAME":"Fojtík Rostislav",
      "s_REAL_NAME_REVERS":"Rostislav Fojtík",
      "s_EMAIL":"rostislav.fojtik@osu.cz",
      "t_DESCRIPTION":"Mgr. Rostislav Fojtík (*1964) vystudoval Pedagogickou fakultu v Ostravě, obor učitelství v předmětech fyzika a základy techniky, dále rozšiřující studium výpočetní techniky na Palackého univerzitě v Olomouci. Působil jako učitel na ZŠ a SPŠ, v současné době je odborným asistentem na katedře informatiky a počítačů na Přírodovědecké fakultě Ostravské univerzity. Http:\/\/www1.osu.cz\/home\/fojtik\/index.htm\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"522",
      "s_REAL_NAME":"Fořt Petr",
      "s_REAL_NAME_REVERS":"Petr Fořt",
      "s_EMAIL":"pet.fort@centrum.cz",
      "t_DESCRIPTION":"Autor desítky učebnic a několika stovek odborných článků s tématikou průmyslového navrhování pomocí digitálních technologií a správy ICT. Dlouholetý pedagog, popularizátor nasazení průmyslových informačních systémů a jejich efektivní administrace. Správce ICT a externí poradce působící v oblasti integrace PLM technologí v průmyslové praxi. Garant a autor strategie oborového vzdělávání projektu SIPVZ a tvůrce národního grantového projektu věnovaného výuce ICT ve strojírenství. Držitel oborových certifikací společností Autodesk, Microsoft a SMC Networks. Školitel modulů Z, P0, P-Grafika, oborový garant modulu P-CAD. Držitel ocenění eLearning Awards a ocenění společnosti 3COM za projekty v oblasti správy informačních systémů a průmyslového navrhování. Autor projektu DesignTech.cz.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"752",
      "s_REAL_NAME":"Franklová, Zoja",
      "s_REAL_NAME_REVERS":"Zoja Franklová,",
      "s_EMAIL":"franklova.z@nuov.cz",
      "t_DESCRIPTION":"Autorka pracuje v Národním ústavu odborného vzdělávání",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"783",
      "s_REAL_NAME":"František, Augusta",
      "s_REAL_NAME_REVERS":"Augusta František,",
      "s_EMAIL":"augustafrantisek@centrum.cz",
      "t_DESCRIPTION":"Působil jako odborný redaktor Armádního technického magazínu, vedoucí rubriky Moderní výuka a výcvik. Jeho otec byl středoškolský profesor.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"410",
      "s_REAL_NAME":"Fuček Miloslav",
      "s_REAL_NAME_REVERS":"Miloslav Fuček",
      "s_EMAIL":"fucek@ekamarad.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"685",
      "s_REAL_NAME":"Fučík Jiří",
      "s_REAL_NAME_REVERS":"Jiří Fučík",
      "s_EMAIL":"atf@swx.cz",
      "t_DESCRIPTION":"Autor pracuje jako metodik ve společnosti SWX, výrobce programů na výuku psaní na klávesnici.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"720",
      "s_REAL_NAME":"Gábrišová Monika",
      "s_REAL_NAME_REVERS":"Monika Gábrišová",
      "s_EMAIL":"Monika_Gabrisova@env.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"542",
      "s_REAL_NAME":"Gálová Dita",
      "s_REAL_NAME_REVERS":"Dita Gálová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"882",
      "s_REAL_NAME":"Gašparovič, Peter",
      "s_REAL_NAME_REVERS":"Peter Gašparovič,",
      "s_EMAIL":"gasparovic@posam.sk",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"696",
      "s_REAL_NAME":"Gawlas Jiří",
      "s_REAL_NAME_REVERS":"Jiří Gawlas",
      "s_EMAIL":"gaw@centrum.cz",
      "t_DESCRIPTION":"Autor vyučuje na základní škole.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"969",
      "s_REAL_NAME":"Gergelitsová, Šárka",
      "s_REAL_NAME_REVERS":"Šárka Gergelitsová,",
      "s_EMAIL":"sarka@gbn.cz",
      "t_DESCRIPTION":"Gymnázium Benešov, Husova 470, 256 01 Benešov; Tel.: 317 785 084",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"995",
      "s_REAL_NAME":"Gobyová, Jitka ",
      "s_REAL_NAME_REVERS":"Jitka Gobyová,",
      "s_EMAIL":"info@skav.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"945",
      "s_REAL_NAME":"Google",
      "s_REAL_NAME_REVERS":"Google",
      "s_EMAIL":"redakce@ceskaskola.cz",
      "t_DESCRIPTION":"Zprávy převzaté z informačních zdrojů Google: Zprávy, Blogy atd.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"452",
      "s_REAL_NAME":"Gracová Blažena",
      "s_REAL_NAME_REVERS":"Blažena Gracová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Doc. PhDr. Blažena Gracová působí na katedře historie Filozofické fakulty Ostravské univerzity.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"26",
      "s_REAL_NAME":"Greger David",
      "s_REAL_NAME_REVERS":"David Greger",
      "s_EMAIL":"david.greger@centrum.cz",
      "t_DESCRIPTION":"Mgr. David Greger\n(*1977), studoval na Pedagogické fakultě Ostravské univerzity obor\nUčitelství pro 1. stupeň ZŠ. V současné době učí na ZŠ v Praze a je postgraduálním studentem pedagogiky na Pedagogické fakultě Univerzity Karlovy.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"397",
      "s_REAL_NAME":"Grombíř Jakub",
      "s_REAL_NAME_REVERS":"Jakub Grombíř",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"680",
      "s_REAL_NAME":"Grombiřík Martin",
      "s_REAL_NAME_REVERS":"Martin Grombiřík",
      "s_EMAIL":"tvi@edunix.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"640",
      "s_REAL_NAME":"Habermann Radomír",
      "s_REAL_NAME_REVERS":"Radomír Habermann",
      "s_EMAIL":"ha@zshust.hranet.cz",
      "t_DESCRIPTION":"Autor je ředitelem ZŠ Hustopeče.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"983",
      "s_REAL_NAME":"Habětínková, Eva ",
      "s_REAL_NAME_REVERS":"Eva Habětínková,",
      "s_EMAIL":"eva.habetinkova@seznam.cz",
      "t_DESCRIPTION":"Zrcadlo.blogspot.com",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"979",
      "s_REAL_NAME":"Habiballa,Hashim ",
      "s_REAL_NAME_REVERS":"Habiballa,Hashim",
      "s_EMAIL":"habiballa@volny.cz",
      "t_DESCRIPTION":"Absolvent Přírodovědecké fakulty Ostravské Univerzity oboru Informatika a výpočetní technika - informační systémy (Mgr. - 1999), dále absolvoval rigorózní zkoušku v oboru Učitelství VVP - specializace informatika na Univerzitě Konštantína Filozofa v Nitře (PaedDr. - 2003) a v roce 2004 úspěšně obhájil disertační práci na téma Využití programovacích metod při výuce teoretické informatiky v rámci doktorandského studia v oboru Teória vyučovania informatiky (PhD.). V roce 2006 na Ostravské Univerzitě vykonal druhou rigorózní zkoušku v oboru Informační systémy (RNDr.). Je odborným asistentem katedry informatiky a počítačů PřF Ostravské Univerzity a během let 2000 až 2004 pracoval také na částečný úvazek na Ústavu pro výzkum a aplikace fuzzy modelování Ostravské Univerzity jako vědecký pracovník (programování VT aplikací). Věnuje se především tvorbě VT a pedagogických aplikací a pedagogickému výzkumu v didaktice informatiky. Dále se zaměřuje na logiku, teorii formálních jazyků a logické programování. Je autorem (v období 2001 - 2006) cca 70 publikací - z toho 16 článků v recenzovaných časopisech, 36 příspěvků ve sbornících z mezinárodních i národních konferencí, 2 recenzované učebnice, 6 učebních textů, 5 graduačních prací.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"415",
      "s_REAL_NAME":"Hadj Moussová Zuzana",
      "s_REAL_NAME_REVERS":"Hadj Moussová Zuzana",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"PhDr. Zuzana Hadj Moussová působí na  katedře školní a pedagogické psychologie Pedagogické fakulty UK. V předchozích letech pracovala jako poradenský psycholog.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"564",
      "s_REAL_NAME":"Hájek Václav ",
      "s_REAL_NAME_REVERS":"Václav Hájek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"749",
      "s_REAL_NAME":"Halada, František",
      "s_REAL_NAME_REVERS":"František Halada,",
      "s_EMAIL":"Frantisek.Halada@cca.cz",
      "t_DESCRIPTION":"Šéfredaktor portálu Škola OnLine. Původním povoláním učitel, po roce 1990 působil 6 let jako ředitel základní školy. Dále pracoval jako školitel a manažer velké obchodní firmy. Podílel se na vybudování a řízení systému vzdělávání v současné firmě. Je ženatý, má dvě dospělé dcery. Rád čte, cestuje, navštěvuje divadlo a poslouchá hudbu.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"418",
      "s_REAL_NAME":"Halla Emil",
      "s_REAL_NAME_REVERS":"Emil Halla",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"JUDr. Emil Halla působí na pracovně - právním odboru Ministerstva školství, mládeže a tělovýchovy ČR.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"45",
      "s_REAL_NAME":"Hanzlíková Iva",
      "s_REAL_NAME_REVERS":"Iva Hanzlíková",
      "s_EMAIL":"iva.hanzlikova@post.cz",
      "t_DESCRIPTION":"Iva Hanzlíková (*1979) je studentkou třetího ročníku Fakulty sociálních studií v Brně, obor psychologie, žurnalistika.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"46",
      "s_REAL_NAME":"Hausenblas Ondřej",
      "s_REAL_NAME_REVERS":"Ondřej Hausenblas",
      "s_EMAIL":"hausen@ecn.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"31",
      "s_REAL_NAME":"Hausner Milan",
      "s_REAL_NAME_REVERS":"Milan Hausner",
      "s_EMAIL":"hausner@lupacovka.cz",
      "t_DESCRIPTION":"Ing. Milan Hausner (*1955) je ředitelem Základní školy Lupáčova. Napsal přes 400 recenzí výukového softwaru, je členem několika hodnotitelských komisí pro výukový software. Zároveň je expertem European Centre for modern languages (Graz, Rakousko) pro využití multimédií a internetu ve výuce. Spravuje ojedinělou sbírku 750 titulů CD ROM s výukovými programy.",
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"500",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"971",
      "s_REAL_NAME":"Havel, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Havel,",
      "s_EMAIL":"havel@fsv.cuni.cz",
      "t_DESCRIPTION":"Jiří Havel (1957) učí na Institutu ekonomických studií FSV. Byl předsedou FNM a místopředsedou vlády. ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"973",
      "s_REAL_NAME":"Havlík, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Havlík,",
      "s_EMAIL":"havlik@schoogle.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"569",
      "s_REAL_NAME":"Havlínová Miluše",
      "s_REAL_NAME_REVERS":"Miluše Havlínová",
      "s_EMAIL":"mhavlin@szu.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"504",
      "s_REAL_NAME":"Hawiger David",
      "s_REAL_NAME_REVERS":"David Hawiger",
      "s_EMAIL":"hawigerd@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"601",
      "s_REAL_NAME":"Heczková Leona",
      "s_REAL_NAME_REVERS":"Leona Heczková",
      "s_EMAIL":"leontynka90@hotmail.com",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"777",
      "s_REAL_NAME":"Hejčíková, Jana",
      "s_REAL_NAME_REVERS":"Jana Hejčíková,",
      "s_EMAIL":"hejcikova@vuppraha.cz",
      "t_DESCRIPTION":"Pracuje v oddělení základního vzdělávání VÚP.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"574",
      "s_REAL_NAME":"Hepner Karel",
      "s_REAL_NAME_REVERS":"Karel Hepner",
      "s_EMAIL":"K.Hepner@seznam.cz",
      "t_DESCRIPTION":"Autor je konzultant v oblasti lidských zdrojů, personálního managementu, řídících a informačních systému a v oblasti projektování systémových změn. V uplynulých deseti letech pracoval ve společnosti Hobéon Groep  podílející se na reformě nizozemského školství, dále spolupracoval mj. s některými českými orgány státní správy (MF, MŠMT, MPSV). V současné době se podílí na přípravě některých krajských dlouhodobých záměrů rozvoje školství. ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"891",
      "s_REAL_NAME":"Heřt, Jiří ",
      "s_REAL_NAME_REVERS":"Jiří Heřt,",
      "s_EMAIL":"jiri.hert@tiscali.cz",
      "t_DESCRIPTION":"Prof. MUDr. Jiří Heřt (*1928) vystudoval Lékařskou fakultu UK v Praze. Na Anatomickém ústavu LF UK v Plzni se zabýval morfologií a funkční adaptací pohybové soustavy.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"488",
      "s_REAL_NAME":"Hladiš Petr",
      "s_REAL_NAME_REVERS":"Petr Hladiš",
      "s_EMAIL":"p_hladis@email.cz",
      "t_DESCRIPTION":"Mgr. Petr Hladiš absolvoval učitelský směr Fakulty informatiky MU v Brně.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"604",
      "s_REAL_NAME":"Hlavatá Eva",
      "s_REAL_NAME_REVERS":"Eva Hlavatá",
      "s_EMAIL":"eva.hlavata@ict-edu.net",
      "t_DESCRIPTION":"Autorka působí na ZŠ na Ul. R. Zaymusa v Žilině, Slovensko.\n\n \n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"425",
      "s_REAL_NAME":"Hlavenka Jiří",
      "s_REAL_NAME_REVERS":"Jiří Hlavenka",
      "s_EMAIL":"jiri.hlavenka@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"551",
      "s_REAL_NAME":"Hloušková Lenka",
      "s_REAL_NAME_REVERS":"Lenka Hloušková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"888",
      "s_REAL_NAME":"Holasová, Táňa ",
      "s_REAL_NAME_REVERS":"Táňa Holasová,",
      "s_EMAIL":"editor@rvp.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"474",
      "s_REAL_NAME":"Holčík Tomáš",
      "s_REAL_NAME_REVERS":"Tomáš Holčík",
      "s_EMAIL":"tomas.holcik@cpress.cz",
      "t_DESCRIPTION":"Autor je šéfredaktorem serveru Živě.cz.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"996",
      "s_REAL_NAME":"Holub, Petr",
      "s_REAL_NAME_REVERS":"Petr Holub,",
      "s_EMAIL":"petr.holub@aktualne.cz",
      "t_DESCRIPTION":"Politický zpravodaj deníku Aktuálně.cz, který spolupracuje také s Českým rozhlasem 6. V domácí redakci má pozici hlavního analytika; kromě politiky se zajímá o zdravotnictví a sociální věci.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"724",
      "s_REAL_NAME":"Hora, Vladimír",
      "s_REAL_NAME_REVERS":"Vladimír Hora,",
      "s_EMAIL":"hora@ped.muni.cz",
      "t_DESCRIPTION":"Pedagogická fakulta MU v Brně, katedra Technické a informační výchovy, Poříčí 31, 603 00 BRNO",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"644",
      "s_REAL_NAME":"Horáková Veronika ",
      "s_REAL_NAME_REVERS":"Veronika Horáková",
      "s_EMAIL":"Wera.horakova@seznam.cz",
      "t_DESCRIPTION":"Autorka vyučuje na základní škole.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"816",
      "s_REAL_NAME":"Horálek, Jakub",
      "s_REAL_NAME_REVERS":"Jakub Horálek,",
      "s_EMAIL":"HoralekJakub@seznam.cz",
      "t_DESCRIPTION":"Absolvent Pedagogické fakulty Jihočeské univerzity v Českých Budějovicích, učitelství pro II. A III. stupeň, obor: Český jazyk - Historie. V současné době pracuje jako učitel na základní škole Křesomyslova v Praze.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"821",
      "s_REAL_NAME":"Horská, Viola",
      "s_REAL_NAME_REVERS":"Viola Horská,",
      "s_EMAIL":"horska@vuppraha.cz",
      "t_DESCRIPTION":"Výzkumný ústav pedagogický v Praze, 2. výzkumná skupina didaktika a metodika vzdělávacích oblastí a oborů, oddělení jazykového a společenskovědního vzdělávání a umění a kultury, koncepce a obsah vzdělávání společenskovědních oborů ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"742",
      "s_REAL_NAME":"Host, Ľubomír ",
      "s_REAL_NAME_REVERS":"Ľubomír Host,",
      "s_EMAIL":"rajo@platon.sk",
      "t_DESCRIPTION":"Člen Platon SDG (<A HREF=\"http:\/\/rajo.platon.sk\/\">rajo.platon.sk<\/A>), slovenské skupiny vývojářů open source software.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"901",
      "s_REAL_NAME":"Hoštička, Jan",
      "s_REAL_NAME_REVERS":"Jan Hoštička,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"ZŠ Táborská v Praze 4",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"646",
      "s_REAL_NAME":"Houška Tomáš",
      "s_REAL_NAME_REVERS":"Tomáš Houška",
      "s_EMAIL":"tomas.houska@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"557",
      "s_REAL_NAME":"Hradecký Vladimír",
      "s_REAL_NAME_REVERS":"Vladimír Hradecký",
      "s_EMAIL":"vladimir.hradecky@2zskolin.cz ",
      "t_DESCRIPTION":"Autor je učitelem na 2. ZŠ v Kolíně. \n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"491",
      "s_REAL_NAME":"Hříbková Lenka",
      "s_REAL_NAME_REVERS":"Lenka Hříbková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"PhDr. Lenka Hříbková, CSc. působí na katedře pedagogické a školní psychologie PedF UK Praha.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"978",
      "s_REAL_NAME":"Hrtoňová, Nina",
      "s_REAL_NAME_REVERS":"Nina Hrtoňová,",
      "s_EMAIL":"nina@ics.muni.cz",
      "t_DESCRIPTION":"ÚVT Masarykovy university",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"546",
      "s_REAL_NAME":"Hrubá Jana",
      "s_REAL_NAME_REVERS":"Jana Hrubá",
      "s_EMAIL":"jana.hruba@ucitelske-listy.cz",
      "t_DESCRIPTION":"Autorka je šéfredaktorkou časopisu Učitelské listy.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"433",
      "s_REAL_NAME":"Hubatka Miloslav",
      "s_REAL_NAME_REVERS":"Miloslav Hubatka",
      "s_EMAIL":"hubatka@evokace.cz",
      "t_DESCRIPTION":"Mgr. Miloslav Hubatka je zástupcem ředitele\nZŠ Loucká ve Znojmě.\n\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"866",
      "s_REAL_NAME":"Hübelová Dana",
      "s_REAL_NAME_REVERS":"Dana Hübelová",
      "s_EMAIL":"hubelova.dana@seznam.cz",
      "t_DESCRIPTION":"PdF MU v Brně, katedra geografie",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"637",
      "s_REAL_NAME":"Hučínová Lucie",
      "s_REAL_NAME_REVERS":"Lucie Hučínová",
      "s_EMAIL":"hucinova@vuppraha.cz",
      "t_DESCRIPTION":"Výzkumný ústav pedagogický v Praze. Členka 1. výzkumné skupiny, která se zabývá obecnými otázkami vzdělávání a výchovy, koncepcí předškolního, základního a středního všeobecného vzdělávání.\n\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"731",
      "s_REAL_NAME":"Hudec Tomáš",
      "s_REAL_NAME_REVERS":"Tomáš Hudec",
      "s_EMAIL":"hudec.t@gym-bohumin.cz",
      "t_DESCRIPTION":"Gymnázium Františka Živného Bohumín\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"944",
      "s_REAL_NAME":"Hybner, Milan",
      "s_REAL_NAME_REVERS":"Milan Hybner,",
      "s_EMAIL":"redakce@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"931",
      "s_REAL_NAME":"ICM",
      "s_REAL_NAME_REVERS":"ICM",
      "s_EMAIL":"icm@adam.cz",
      "t_DESCRIPTION":"Informační centrum pro mládež",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"933",
      "s_REAL_NAME":"info elearningeuropa.",
      "s_REAL_NAME_REVERS":"elearningeuropa. info",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Portál elearningeuropa.info byl vytvořen Evropskou komisí a má za cíl podporovat používání multimediálních a internetových technologií v oblasti výuky a školení.\n\nPortál poskytuje informace, služby a zdroje zaměřené na čtyři hlavní zájmové oblasti: základní a střední školy, vysoké školy, studium při zaměstnání a celoživotní vzdělávání. Sekce Jak používat elearningeuropa.info nabízí praktické informace o možnostech prohlížení stránek na tomto portálu.\n\nPortál elearningeuropa.info je otevřenou platformou pro všechny zainteresované aktéry a skupiny, aby si předávali informace a zkušenosti, zajišťovali šíření a propagaci svých projektů a organizovali debaty. Vyzýváme Vás k zasílání komentářů a přípomínek, které nám pomohou vylepšit a obohatit obsah portálu. Doporučujeme zaregistrovat se, což Vám umožní přístup ke všem našim službám. Registrace na portál elearningeuropa.info je bezplatná.\nKontaktujte nás: info@elearningeuropa.info\nMáte-li v úmyslu napsat clánek, konzultujte prosím stránku pokyny pro autory příspěvků.\n\nPortál elearningeuropa.info je iniciativou Evropské komise. Tvoří nedílnou součást programu eLearning, který je řízen jednotkou multimédií Generálního ředitelství pro vzdělávání a kulturu.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"878",
      "s_REAL_NAME":"Jáchim, František ",
      "s_REAL_NAME_REVERS":"František Jáchim,",
      "s_EMAIL":"zs.volyne@tiscali.cz",
      "t_DESCRIPTION":"Základní škola Volyně, Vyšší odborná škola a Střední průmyslová škola Volyně",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"487",
      "s_REAL_NAME":"Jakub Lohniský Jakub Pecha,",
      "s_REAL_NAME_REVERS":"Jakub Lohniský Jakub Pecha,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"914",
      "s_REAL_NAME":"Jalovec Antonín ",
      "s_REAL_NAME_REVERS":"Antonín Jalovec",
      "s_EMAIL":"jalovec@gymcheb.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"484",
      "s_REAL_NAME":"Jan Hučín Petr Suchomel,",
      "s_REAL_NAME_REVERS":"Jan Hučín Petr Suchomel,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"921",
      "s_REAL_NAME":"Janoušková Svatava",
      "s_REAL_NAME_REVERS":"Svatava Janoušková",
      "s_EMAIL":"janouskova@vup­praha.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"889",
      "s_REAL_NAME":"Janoušková, Hanka ",
      "s_REAL_NAME_REVERS":"Hanka Janoušková,",
      "s_EMAIL":"editor@rvp.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"42",
      "s_REAL_NAME":"Jansa Radim",
      "s_REAL_NAME_REVERS":"Radim Jansa",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"707",
      "s_REAL_NAME":"Jaroslav Winter",
      "s_REAL_NAME_REVERS":"Winter Jaroslav",
      "s_EMAIL":"winter@brezen.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"609",
      "s_REAL_NAME":"Jednota školských informatiků",
      "s_REAL_NAME_REVERS":"Jednota školských informatiků",
      "s_EMAIL":"jsi@jsi.cz ",
      "t_DESCRIPTION":"JŠI je profesní organizací, která si klade za cíl sdružovat pedagogy a odborníky, kteří se zabývají ICT. Více informací naleznete na www.jsi.cz.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"585",
      "s_REAL_NAME":"Jelínková Radka",
      "s_REAL_NAME_REVERS":"Radka Jelínková",
      "s_EMAIL":"redakce@ucitelske-listy.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"946",
      "s_REAL_NAME":"Jeřábková, Danuše",
      "s_REAL_NAME_REVERS":"Danuše Jeřábková,",
      "s_EMAIL":"danuse.jerabkova@gmail.com",
      "t_DESCRIPTION":"Učitelka vesnické ZŠ.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"607",
      "s_REAL_NAME":"Ježek Lukáš",
      "s_REAL_NAME_REVERS":"Lukáš Ježek",
      "s_EMAIL":"lukas.jezek@volny.cz",
      "t_DESCRIPTION":"Autor je studentem gymnázia F.X. Šaldy v Liberci.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"898",
      "s_REAL_NAME":"Ježková, Jaroslava",
      "s_REAL_NAME_REVERS":"Jaroslava Ježková,",
      "s_EMAIL":"j_jezkova@gasos-ro.cz",
      "t_DESCRIPTION":"Gymnázium a Střední odborná škola Rokycany",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"669",
      "s_REAL_NAME":"Jílková Jana",
      "s_REAL_NAME_REVERS":"Jana Jílková",
      "s_EMAIL":"jilkova.icvkh@tiscali.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"18",
      "s_REAL_NAME":"Jírovec Jiří",
      "s_REAL_NAME_REVERS":"Jiří Jírovec",
      "s_EMAIL":"jirovecj@magma.ca",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"819",
      "s_REAL_NAME":"Jonák, Zdeněk",
      "s_REAL_NAME_REVERS":"Zdeněk Jonák,",
      "s_EMAIL":"jonak@vuppraha.cz",
      "t_DESCRIPTION":"Výzkumný ústav pedagogický v Praze, 2. výzkumná skupina didaktika a metodika vzdělávacích oblastí a oborů, oddělení přírodních věd, matematiky, ICT, zdraví a světa práce, koncepce a obsah vzdělávání informačních a komunikačních technologií ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"587",
      "s_REAL_NAME":"Jucovičová Drahomíra",
      "s_REAL_NAME_REVERS":"Drahomíra Jucovičová",
      "s_EMAIL":"redakce@ucitelske-listy.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"620",
      "s_REAL_NAME":"Jurčík Tomáš",
      "s_REAL_NAME_REVERS":"Tomáš Jurčík",
      "s_EMAIL":"jurcik-tom@volny.cz",
      "t_DESCRIPTION":"Autor je středoškolským pedagogem a předsedou Společnosti středoškolských pedagogů.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"22",
      "s_REAL_NAME":"Kabeš Petr",
      "s_REAL_NAME_REVERS":"Petr Kabeš",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"540",
      "s_REAL_NAME":"Kačer Jindřich",
      "s_REAL_NAME_REVERS":"Jindřich Kačer",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"953",
      "s_REAL_NAME":"Kafka, Daniel ",
      "s_REAL_NAME_REVERS":"Daniel Kafka,",
      "s_EMAIL":"d.kafka@zsmojzir.cz",
      "t_DESCRIPTION":"Autor učí na Základní škole Ústí nad Labem.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"905",
      "s_REAL_NAME":"Kaiser, Daniel",
      "s_REAL_NAME_REVERS":"Daniel Kaiser,",
      "s_EMAIL":"dkaiser@zsjizni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"494",
      "s_REAL_NAME":"Kalina Petr",
      "s_REAL_NAME_REVERS":"Petr Kalina",
      "s_EMAIL":"chinin@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"613",
      "s_REAL_NAME":"Kalous Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Kalous",
      "s_EMAIL":"jaroslav.kalous@ucitelske-listy.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"638",
      "s_REAL_NAME":"Kamenická Renata",
      "s_REAL_NAME_REVERS":"Renata Kamenická",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"740",
      "s_REAL_NAME":"Kapica, Aleš, Wikipedia",
      "s_REAL_NAME_REVERS":"Kapica, Aleš, Wikipedia",
      "s_EMAIL":"ales.kapica@ovajih.cz",
      "t_DESCRIPTION":"správce sítě, Wikipedista",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"501",
      "s_REAL_NAME":"Karásková Vlasta",
      "s_REAL_NAME_REVERS":"Vlasta Karásková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"798",
      "s_REAL_NAME":"Kartous, Bohumil ",
      "s_REAL_NAME_REVERS":"Bohumil Kartous,",
      "s_EMAIL":"bkartous@scio.cz",
      "t_DESCRIPTION":"Pracuje ve společnosti Scio, kde mimo jiné zajišťuji poradenské a prezentační články v médiích.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"738",
      "s_REAL_NAME":"Kašparec, Jakub ",
      "s_REAL_NAME_REVERS":"Jakub Kašparec,",
      "s_EMAIL":"mr.K@centrum.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"808",
      "s_REAL_NAME":"Kašpárek, Ladislav",
      "s_REAL_NAME_REVERS":"Ladislav Kašpárek,",
      "s_EMAIL":"kasparek@sps-jia.cz",
      "t_DESCRIPTION":"Střední průmyslová škola, Legionářů 3, 586 01 Jihlava; tel.: 777 022 334",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"879",
      "s_REAL_NAME":"Kašpárková Jana",
      "s_REAL_NAME_REVERS":"Jana Kašpárková",
      "s_EMAIL":"kasparkova.jana@post.cz",
      "t_DESCRIPTION":"Pedagogická fakulta Univerzity Palackého v Olomouci",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"525",
      "s_REAL_NAME":"Kilián ml. Karel",
      "s_REAL_NAME_REVERS":"Kilián ml. Karel",
      "s_EMAIL":"karel.kilian@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"541",
      "s_REAL_NAME":"Kitzberger Jindřich",
      "s_REAL_NAME_REVERS":"Jindřich Kitzberger",
      "s_EMAIL":"j.kitzberger@interbrigady.cz",
      "t_DESCRIPTION":"Autor je ředitelem ZŠ nám. Interbrigády v Praze, místopředsedou Asociace pedagogů základního školství a mluvčí Stálé konference asociací ve \nvzdělávání.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"745",
      "s_REAL_NAME":"Klapal, Václav",
      "s_REAL_NAME_REVERS":"Václav Klapal,",
      "s_EMAIL":"vaclavklapal@upol.cz",
      "t_DESCRIPTION":"Odborný asistent katedry pedagogiky Pedagogické fakulty Univerzity Palackého v Olomouci.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"535",
      "s_REAL_NAME":"Klaschková Libuše",
      "s_REAL_NAME_REVERS":"Libuše Klaschková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"934",
      "s_REAL_NAME":"Klimeš, Ivan",
      "s_REAL_NAME_REVERS":"Ivan Klimeš,",
      "s_EMAIL":"ivan.klimes@ff.cuni.cz",
      "t_DESCRIPTION":"Vedoucí katedry filmových studíí Karlovy university.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"616",
      "s_REAL_NAME":"Klusáčková Renata",
      "s_REAL_NAME_REVERS":"Renata Klusáčková",
      "s_EMAIL":"klusackova.renata@quick.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"534",
      "s_REAL_NAME":"Knihová Ladislava",
      "s_REAL_NAME_REVERS":"Ladislava Knihová",
      "s_EMAIL":"kniha@telecom.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"583",
      "s_REAL_NAME":"Kocan Marek ",
      "s_REAL_NAME_REVERS":"Marek Kocan",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Autor je spolupracovníkem časopisu Computer.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"660",
      "s_REAL_NAME":"Koch Karel",
      "s_REAL_NAME_REVERS":"Karel Koch",
      "s_EMAIL":"karelkoch@volny.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"730",
      "s_REAL_NAME":"Kocichová Dagmar",
      "s_REAL_NAME_REVERS":"Dagmar Kocichová",
      "s_EMAIL":"dasakocichova@centrum.cz",
      "t_DESCRIPTION":"Gymnázium Hladnov, Slezská Ostrava, 710 00, Ostrava-Slezská Ostrava; tel.: 595 24 10 73",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"746",
      "s_REAL_NAME":"Kodymová, Nina ",
      "s_REAL_NAME_REVERS":"Nina Kodymová,",
      "s_EMAIL":"nk@jacr.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"938",
      "s_REAL_NAME":"Kolátorová, Ivana",
      "s_REAL_NAME_REVERS":"Ivana Kolátorová,",
      "s_EMAIL":"redakce@eskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"407",
      "s_REAL_NAME":"kolektiv autorů Alter -",
      "s_REAL_NAME_REVERS":"kolektiv autorů Alter -",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"406",
      "s_REAL_NAME":"kolektiv autorů Alter",
      "s_REAL_NAME_REVERS":"kolektiv autorů Alter",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"545",
      "s_REAL_NAME":"Kolínská Jana",
      "s_REAL_NAME_REVERS":"Jana Kolínská",
      "s_EMAIL":"kolinska@cermat.cz",
      "t_DESCRIPTION":"RNDr. Jana Kolínská působí jako předmětový koordinátor pro fyziku v Centru pro reformu maturitní zkoušky.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"659",
      "s_REAL_NAME":"Kolman Petr",
      "s_REAL_NAME_REVERS":"Petr Kolman",
      "s_EMAIL":"petr.kolman@law.muni.cz",
      "t_DESCRIPTION":"JUDr. Petr Kolman působí na Právnické fakultě Masarykovy univerzity v Brně.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"625",
      "s_REAL_NAME":"Kopecký Kamil",
      "s_REAL_NAME_REVERS":"Kamil Kopecký",
      "s_EMAIL":"kamil.kopecky@net-university.cz",
      "t_DESCRIPTION":"Mgr. Kamil Kopecký působí na katedře českého jazyka a literatury PdF UP v Olomouci.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"556",
      "s_REAL_NAME":"Kopřivová Ivana",
      "s_REAL_NAME_REVERS":"Ivana Kopřivová",
      "s_EMAIL":"griesselova@atlas.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"590",
      "s_REAL_NAME":"Kopta Martin",
      "s_REAL_NAME_REVERS":"Martin Kopta",
      "s_EMAIL":"martin.kopta@garcon.cz",
      "t_DESCRIPTION":"Autor studuje učitelství českého jazyku, literatury a společenských věd na PedF UK. Pravidelně publikuje na serveru Lupa.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"976",
      "s_REAL_NAME":"Kosíková, Věra",
      "s_REAL_NAME_REVERS":"Věra Kosíková,",
      "s_EMAIL":"kosikov@kpg.zcu.cz",
      "t_DESCRIPTION":"Pedagogická fakulta ZČU",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"687",
      "s_REAL_NAME":"Kosina Pavel",
      "s_REAL_NAME_REVERS":"Pavel Kosina",
      "s_EMAIL":"kosina@szscv.cz",
      "t_DESCRIPTION":"Autor vyučuje na Střední zdravotnické škole v Chomutově.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"781",
      "s_REAL_NAME":"Košťálová, Vlasta",
      "s_REAL_NAME_REVERS":"Vlasta Košťálová,",
      "s_EMAIL":"vkostalova@svatojanskakolej.cz",
      "t_DESCRIPTION":"Svatojánská kolej, VOŠ pedagogická, Svatý Jan pod Skalou.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"532",
      "s_REAL_NAME":"Kostečka Jiří",
      "s_REAL_NAME_REVERS":"Jiří Kostečka",
      "s_EMAIL":"kos.jiri@seznam.cz",
      "t_DESCRIPTION":"Autor je pedagog na Gymnáziu J. Seiferta v Praze.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"943",
      "s_REAL_NAME":"Kotulek, Milan ",
      "s_REAL_NAME_REVERS":"Milan Kotulek,",
      "s_EMAIL":"milank@centrum.cz",
      "t_DESCRIPTION":"Vyučuje Informatice na Základní škole Bohumila Hrabala v Praze 8",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"691",
      "s_REAL_NAME":"Koucký Jan",
      "s_REAL_NAME_REVERS":"Jan Koucký",
      "s_EMAIL":"jan.koucky@msmt.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"412",
      "s_REAL_NAME":"Koutňáková Anna",
      "s_REAL_NAME_REVERS":"Anna Koutňáková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"766",
      "s_REAL_NAME":"Kovář, Michal",
      "s_REAL_NAME_REVERS":"Michal Kovář,",
      "s_EMAIL":"michalkolar@volny.cz",
      "t_DESCRIPTION":"Etoped a psychoterapeut. Řešením šikanování se zabývá více než pětadvacet let. Vytvořil původní speciální teorii a metodiku diagnostiky a léčby školního šikanování. Je autorem knih Skrytý svět šikanování ve školách a Bolest šikanování. Publikuje v odborných a populárních časopisech. Odborně garantoval videofilm \"Dětská šikana\". Problematiku šikanování přednáší na vysokých školách. V posledních sedmi letech se snaží v rámci možností uspokojovat zájem pedagogů a dalších odborníků z celé republiky o modulové výcvikové kurzy zaměřené na prevenci šikanování. Kromě toho poskytuje konzultace, supervize a poradenskou službu. Spolupracuje s MŠMT na koncepci prevence tohoto celospolečensky závažného problému.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"864",
      "s_REAL_NAME":"Kovařovic, Jan",
      "s_REAL_NAME_REVERS":"Jan Kovařovic,",
      "s_EMAIL":"jan.kovarovic@pedf.cuni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"839",
      "s_REAL_NAME":"Kozák, Milan",
      "s_REAL_NAME_REVERS":"Milan Kozák,",
      "s_EMAIL":"redakce@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"834",
      "s_REAL_NAME":"Kozáková, Blanka",
      "s_REAL_NAME_REVERS":"Blanka Kozáková,",
      "s_EMAIL":"blanka.kozakova@kvic.cz",
      "t_DESCRIPTION":"Vedoucí koordinátor projektů a rozvojových programů Krajského zařízení pro další vzdělávání pedagogických pracovníků a informační centrum, Nový Jičín",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"948",
      "s_REAL_NAME":"Krámská, Zdena ",
      "s_REAL_NAME_REVERS":"Zdena Krámská,",
      "s_EMAIL":"kramska.zdena@cmkos.cz",
      "t_DESCRIPTION":"Právník ČMOS PŠ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"805",
      "s_REAL_NAME":"Kratochvíl, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Kratochvíl,",
      "s_EMAIL":"jirka.kratochvil@seznam.cz",
      "t_DESCRIPTION":"Autor je absolventem Pedagogické fakulty Masarykovy univerzity v Brně.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"927",
      "s_REAL_NAME":"Kraus, Josef",
      "s_REAL_NAME_REVERS":"Josef Kraus,",
      "s_EMAIL":"josef.kraus@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"900",
      "s_REAL_NAME":"Krbcová, Jitka",
      "s_REAL_NAME_REVERS":"Jitka Krbcová,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"871",
      "s_REAL_NAME":"Krčková, Stanislava ",
      "s_REAL_NAME_REVERS":"Stanislava Krčková,",
      "s_EMAIL":"krckova@vuppraha.cz",
      "t_DESCRIPTION":"Náměstkyně ředitele VÚP Praha",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"711",
      "s_REAL_NAME":"Krejčí Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Krejčí",
      "s_EMAIL":"krejci@zstenis.com",
      "t_DESCRIPTION":"Učitel IT a správce sítě ZŠ Přerov, U Tenisu 4, <A HREF=\"http:\/\/new.zstenis.com\/\">http:\/\/new.zstenis.com<\/A>",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"510",
      "s_REAL_NAME":"Křístek Nikola",
      "s_REAL_NAME_REVERS":"Nikola Křístek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"493",
      "s_REAL_NAME":"Kříž Libor",
      "s_REAL_NAME_REVERS":"Libor Kříž",
      "s_EMAIL":"libor.kriz@cpress.cz",
      "t_DESCRIPTION":"Autor je zástupcem šéfredaktora časopisu Computer.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"388",
      "s_REAL_NAME":"Krupička Robert",
      "s_REAL_NAME_REVERS":"Robert Krupička",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"873",
      "s_REAL_NAME":"Kubeš, Josef ",
      "s_REAL_NAME_REVERS":"Josef Kubeš,",
      "s_EMAIL":"josef.kubes@mikulasske.cz",
      "t_DESCRIPTION":"Gymnázium, Plzeň, Mikulášské nám. 23",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"475",
      "s_REAL_NAME":"Kucharská Anna",
      "s_REAL_NAME_REVERS":"Anna Kucharská",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Autorka působí na katedře pedagogické a školní psychologie PedF UK a současně v pedagogicko-psychologické poradně.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"485",
      "s_REAL_NAME":"Kuchler Karel",
      "s_REAL_NAME_REVERS":"Karel Kuchler",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Autor působí na ústředí České školní inspekce.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"828",
      "s_REAL_NAME":"Kudyvejs, Miroslav ",
      "s_REAL_NAME_REVERS":"Miroslav Kudyvejs,",
      "s_EMAIL":"kudyvejs@zshorakhk.cz",
      "t_DESCRIPTION":"Ředitel ZŠ Milady Horákové v Hradci Králové",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"428",
      "s_REAL_NAME":"Kukal Petr",
      "s_REAL_NAME_REVERS":"Petr Kukal",
      "s_EMAIL":"petr.kukal@seznam.cz",
      "t_DESCRIPTION":"Autor je publicista. ",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"850",
      "s_REAL_NAME":"Kulhánek,Milan ",
      "s_REAL_NAME_REVERS":"Kulhánek,Milan",
      "s_EMAIL":"redakce@ceskaskola.cz",
      "t_DESCRIPTION":"Středoškolský profesor (český jazyk, dějepis) a průvodce cestovního ruchu. V devadesátých letech působil na SOU a SOŠ SČMSD obchodní v Broumově. V letech 2001-2003 přednášel na Státní vysoké škole ve Walbrzychu (Polsko) od r 2000 vyučuje na Gymnáziu Broumov. Je členem Rady města Broumova za SNK-Stěnava, předsedou komise pro cestovní ruch a služby a předsedou školské rady broumovského gymnázia.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"663",
      "s_REAL_NAME":"Kunzová Zuzana",
      "s_REAL_NAME_REVERS":"Zuzana Kunzová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"432",
      "s_REAL_NAME":"Kusala Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Kusala",
      "s_EMAIL":"kusalaj@hotmail.com",
      "t_DESCRIPTION":"RNDr. Jaroslav Kusala vyučuje fyziku a informatiku na \nvsetínském gymnaziu. Kromě tvorby výukových programů se zabýva také \nproblematikou školního využívaní internetu (např. publikace Internet ve škole, Fortuna 2000).\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"463",
      "s_REAL_NAME":"Kváča Martin",
      "s_REAL_NAME_REVERS":"Martin Kváča",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Autor je pedagogem na Gymnáziu Oty Pavla v Praze.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"760",
      "s_REAL_NAME":"Kysela, Václav",
      "s_REAL_NAME_REVERS":"Václav Kysela,",
      "s_EMAIL":"kysela@scomp.cz",
      "t_DESCRIPTION":"eLearning konzultant",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"416",
      "s_REAL_NAME":"Lachsová Marie",
      "s_REAL_NAME_REVERS":"Marie Lachsová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"502",
      "s_REAL_NAME":"Lariš Rostislav",
      "s_REAL_NAME_REVERS":"Rostislav Lariš",
      "s_EMAIL":"xlar@seznam.cz",
      "t_DESCRIPTION":"Autor je pedagogem na ZŠ Mšené-lázně.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"48",
      "s_REAL_NAME":"Lauermann Marek",
      "s_REAL_NAME_REVERS":"Marek Lauermann",
      "s_EMAIL":"lauermann@email.cz",
      "t_DESCRIPTION":"Marek Lauermann (*1973) studoval v letech na Pedagogické fakultě UK v Praze občanskou výchovu, pedagogiku a školský management. V r. 1998 nastoupil na ZŠ Pavlovská v Brně, kde dnes působí jako manager komunitního projektu Škola jako centrum komunity. Současně již druhým rokem externě přednáší dějiny\nžidovské kultury na DIFA JAMU v Brně.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"679",
      "s_REAL_NAME":"Lazarová Bohumíra",
      "s_REAL_NAME_REVERS":"Bohumíra Lazarová",
      "s_EMAIL":"lazarova@jumbo.muni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"774",
      "s_REAL_NAME":"Lederbuchová, Ladislava ",
      "s_REAL_NAME_REVERS":"Ladislava Lederbuchová,",
      "s_EMAIL":"ladislava.lederbuchova@pedf.cuni.cz",
      "t_DESCRIPTION":"Katedra české literatury Pedagogické fakulty UK ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"980",
      "s_REAL_NAME":"Lencová, Radana",
      "s_REAL_NAME_REVERS":"Radana Lencová,",
      "s_EMAIL":"radana@lencova.eu",
      "t_DESCRIPTION":"* 2. 11. 1975 v Žatci. Studovala na VŠUP v Praze (1994–2000), následně v doktorském studiu na stejné škole s tématem „Kaligrafie dnes – rukopisné písmo“ (2002–2005). Věnuje se grafickému designu a výtvarným experimentům kombinujícím písmo, světlo a tanec (projekt „Přeměna odpadu – proměna duše“), grafické úpravě knih (nakladatelství Svět) a volné kaligrafii. V edici „Kaligrafie“ vydala autorské knihy „Rozhovory o písmu rukopisném“\n(2007) a „Comenia Script, praktický manuál“ (2008). Na Mezinárodním bienále grafického designu v Brně obdržela několik cen (1996, 1998, 2000), dále ocenění v soutěži Nejkrásnější české knihy (2002, 2003, 2008). www.lencova.eu",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"824",
      "s_REAL_NAME":"Lesáková, Eva",
      "s_REAL_NAME_REVERS":"Eva Lesáková,",
      "s_EMAIL":"lesakova@cermat.cz",
      "t_DESCRIPTION":"Koordinátorka matematiky v Centru pro zjišťování výsledků vzdělávání",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"790",
      "s_REAL_NAME":"Lhoták, Martin",
      "s_REAL_NAME_REVERS":"Martin Lhoták,",
      "s_EMAIL":"lhotak@lib.cas.cz",
      "t_DESCRIPTION":"Pracuje v oddělení IT v Knihovně Akademie věd ČR",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"581",
      "s_REAL_NAME":"Lindovský Ivo ",
      "s_REAL_NAME_REVERS":"Ivo Lindovský",
      "s_EMAIL":"ivo.lindovsky@cpress.cz",
      "t_DESCRIPTION":"Autor je redaktorem časopisu Computer.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"449",
      "s_REAL_NAME":"Linhart Jan",
      "s_REAL_NAME_REVERS":"Jan Linhart",
      "s_EMAIL":"janlinhart@email.cz",
      "t_DESCRIPTION":"Mgr. Jan Linhart je zástupcem ředitele Zvláštní školy Praha 3.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"675",
      "s_REAL_NAME":"Lippmann Karel",
      "s_REAL_NAME_REVERS":"Karel Lippmann",
      "s_EMAIL":"lippmann@elsatnet.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"469",
      "s_REAL_NAME":"Lipšanský Jan",
      "s_REAL_NAME_REVERS":"Jan Lipšanský",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Autor je editorem internetového portálu World Online CZ.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"957",
      "s_REAL_NAME":"Liška, Ondřej",
      "s_REAL_NAME_REVERS":"Ondřej Liška,",
      "s_EMAIL":"ondrej.liska@msmt.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"623",
      "s_REAL_NAME":"listy Učitelské",
      "s_REAL_NAME_REVERS":"Učitelské listy",
      "s_EMAIL":"redakce@ucitelske-listy.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"572",
      "s_REAL_NAME":"Lohniský Jakub ",
      "s_REAL_NAME_REVERS":"Jakub Lohniský",
      "s_EMAIL":"jakub.lohnisky@cpress.cz",
      "t_DESCRIPTION":"Autor je stálým spolupracovníkem časopisu Computer.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"538",
      "s_REAL_NAME":"Lovas Pavel",
      "s_REAL_NAME_REVERS":"Pavel Lovas",
      "s_EMAIL":"lovas@gymkrom.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"619",
      "s_REAL_NAME":"Lucie Tvarůžková – TÝDEN",
      "s_REAL_NAME_REVERS":"Lucie Tvarůžková – TÝDEN",
      "s_EMAIL":"tvaruzkova@tyden.cz",
      "t_DESCRIPTION":"Autorka je redaktorkou časopisu Týden. ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"803",
      "s_REAL_NAME":"Luger, Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Luger,",
      "s_EMAIL":"jaroslav.luger@seznam.cz",
      "t_DESCRIPTION":"Autor časopisu LinuxEXPRES",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"517",
      "s_REAL_NAME":"Lukáš Ivan",
      "s_REAL_NAME_REVERS":"Ivan Lukáš",
      "s_EMAIL":"ivan.lukas@cpress.cz",
      "t_DESCRIPTION":"Autor je redaktorem časopisu Mobility.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"908",
      "s_REAL_NAME":"Lutonský Marek ",
      "s_REAL_NAME_REVERS":"Marek Lutonský",
      "s_EMAIL":"marek.lutonsky@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"967",
      "s_REAL_NAME":"Lysoněk, Ivo",
      "s_REAL_NAME_REVERS":"Ivo Lysoněk,",
      "s_EMAIL":"lysonek@guh.cz",
      "t_DESCRIPTION":"Gymnázium Uherské Hradiště, Velehradská třída 218, 686 17 Uherské Hradiště; Tel.: 572 434 150",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"390",
      "s_REAL_NAME":"M. Anna",
      "s_REAL_NAME_REVERS":"Anna M.",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"531",
      "s_REAL_NAME":"Maca Radek",
      "s_REAL_NAME_REVERS":"Radek Maca",
      "s_EMAIL":"rama@inforama.cz",
      "t_DESCRIPTION":"Autor externě vyučuje na ZŠ a SŠ a je\nprogramovým garantem konferencí Počítač na základní škole a Didaktika pod lupou.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"478",
      "s_REAL_NAME":"Macek Ondřej",
      "s_REAL_NAME_REVERS":"Ondřej Macek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"568",
      "s_REAL_NAME":"Mach Martin",
      "s_REAL_NAME_REVERS":"Martin Mach",
      "s_EMAIL":"machx@tiscali.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"840",
      "s_REAL_NAME":"Mach, Jindřich",
      "s_REAL_NAME_REVERS":"Jindřich Mach,",
      "s_EMAIL":"jindrich.mach@iweta.cz",
      "t_DESCRIPTION":"V současné době koordinátor projektu IWETA, prezident Asociace renovátorů ČR, nadporučík v záloze, dlouholetý pracovník v oblasti informačních technologií, kdysi učitel; rád připíjí na krásu našich koní a rychlost našich žen, milovník krásné literatury, dějepravy a amatérské astronomie ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"61",
      "s_REAL_NAME":"Mácová Šárka",
      "s_REAL_NAME_REVERS":"Šárka Mácová",
      "s_EMAIL":"macova@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"844",
      "s_REAL_NAME":"Maixner Lukáš ",
      "s_REAL_NAME_REVERS":"Lukáš Maixner",
      "s_EMAIL":"redakce@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"702",
      "s_REAL_NAME":"Majstrová Zuzana",
      "s_REAL_NAME_REVERS":"Zuzana Majstrová",
      "s_EMAIL":"zuzanam@majstr.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"845",
      "s_REAL_NAME":"Máliková, Markéta",
      "s_REAL_NAME_REVERS":"Markéta Máliková,",
      "s_EMAIL":"redakce@ikaros.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"676",
      "s_REAL_NAME":"Malinovský Jakub",
      "s_REAL_NAME_REVERS":"Jakub Malinovský",
      "s_EMAIL":"jakub_m@volny.cz",
      "t_DESCRIPTION":"Autor studuje na VŠ.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"932",
      "s_REAL_NAME":"Maňák, Vratislav",
      "s_REAL_NAME_REVERS":"Vratislav Maňák,",
      "s_EMAIL":"vrasm@centrum.cz",
      "t_DESCRIPTION":"Student žurnalistiky na FSV UK v Praze ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"550",
      "s_REAL_NAME":"Mannová Božena ",
      "s_REAL_NAME_REVERS":"Božena Mannová",
      "s_EMAIL":"mannova@cslab.felk.cvut.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"402",
      "s_REAL_NAME":"Mařasová Hana",
      "s_REAL_NAME_REVERS":"Hana Mařasová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"505",
      "s_REAL_NAME":"Marek Aleš",
      "s_REAL_NAME_REVERS":"Aleš Marek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"453",
      "s_REAL_NAME":"Marek Josef",
      "s_REAL_NAME_REVERS":"Josef Marek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Ing. Josef Marek působí v Pražském ekologickém centru.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"918",
      "s_REAL_NAME":"Marek Vlastimil ",
      "s_REAL_NAME_REVERS":"Vlastimil Marek",
      "s_EMAIL":"barakan@volny.cz",
      "t_DESCRIPTION":"Celoživotně alternativní hudebník, publicista, spisovatel a duchovní učitel. Informace o přednáškách, seminářích a koncertech buď na blogu http:\/\/marek.blog.respekt.cz nebo na http:\/\/www.cestazeny.cz.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"408",
      "s_REAL_NAME":"Marintz Jan",
      "s_REAL_NAME_REVERS":"Jan Marintz",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"820",
      "s_REAL_NAME":"Maršák, Jan",
      "s_REAL_NAME_REVERS":"Jan Maršák,",
      "s_EMAIL":"marsak@vuppraha.cz",
      "t_DESCRIPTION":"Výzkumný ústav pedagogický v Praze, vedoucí 2. výzkumné skupiny, didaktika a metodika vzdělávacích oblastí a oborů",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"836",
      "s_REAL_NAME":"Martásková, Zuzana ",
      "s_REAL_NAME_REVERS":"Zuzana Martásková,",
      "s_EMAIL":"zmartaskova@scio-ops.cz",
      "t_DESCRIPTION":"Manažerka projektu Internetové kluby ČH@VE, Scio, o.p.s.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"426",
      "s_REAL_NAME":"Martincová Nora",
      "s_REAL_NAME_REVERS":"Nora Martincová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"PhDr. Nora Martincová pracuje v PPP Kouřim.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"942",
      "s_REAL_NAME":"Martínek, Jan",
      "s_REAL_NAME_REVERS":"Jan Martínek,",
      "s_EMAIL":"martinek@trebesin.cz",
      "t_DESCRIPTION":"STIC – Centrum moderních technologií ve škole, SPŠ Na Třebešíně ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"975",
      "s_REAL_NAME":"Martišek, Dalibor",
      "s_REAL_NAME_REVERS":"Dalibor Martišek,",
      "s_EMAIL":"martisek@fme.vutbr.cz",
      "t_DESCRIPTION":"Vysokoškolský učitel (matematika, programování, počítačová grafika) ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"960",
      "s_REAL_NAME":"Maryška, Miloš",
      "s_REAL_NAME_REVERS":"Miloš Maryška,",
      "s_EMAIL":"milos.maryska@vse.cz",
      "t_DESCRIPTION":"Katedra informačních technologií  VŠE v Praze",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"633",
      "s_REAL_NAME":"Maryšková Štěpánka ",
      "s_REAL_NAME_REVERS":"Štěpánka Maryšková",
      "s_EMAIL":"maryskova@centrum.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"477",
      "s_REAL_NAME":"Maškarinec Petr",
      "s_REAL_NAME_REVERS":"Petr Maškarinec",
      "s_EMAIL":"maskarinec@volny.cz",
      "t_DESCRIPTION":"Autor je učitelem informatiky na ZŠ s počítačovým zaměřením v Liberci.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"776",
      "s_REAL_NAME":"Maťašová, Zuzana",
      "s_REAL_NAME_REVERS":"Zuzana Maťašová,",
      "s_EMAIL":"matasova@vuppraha.cz",
      "t_DESCRIPTION":"Pracuje na VÚP jako specialistka na hodnocení a autoevaluaci v oddělení srovnávací pedagogiky a pedagogických výzkumů.\n\nVystudovala Pedagogickou fakultu na Prešovské univerzitě. V roce 2003 ukončila postgraduální studium v kterém se věnovala výzkumu PZM (preferenčních způsobů myšlení). Publikuje pro akademickou obec v rámci aplikace PZM v pedagogice.\nJejí specialitou je přizpůsobení PZM na různé oblasti managementu, marketingu, ekonomiky a práce s lidmi. Dále rozvíjení komunikačních dovedností, rozpoznávání preferenčních způsobů myšlení, aplikace tvořivé strategie.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"460",
      "s_REAL_NAME":"Matějček Zdeněk",
      "s_REAL_NAME_REVERS":"Zdeněk Matějček",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"prof. PhDr. Zdeněk Matějček, CSc. působí v Psychiatrickém centru Praha",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"27",
      "s_REAL_NAME":"Matějů Petr",
      "s_REAL_NAME_REVERS":"Petr Matějů",
      "s_EMAIL":"mateju@psp.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"462",
      "s_REAL_NAME":"Matoušek Petr",
      "s_REAL_NAME_REVERS":"Petr Matoušek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"571",
      "s_REAL_NAME":"Matúš Zdeněk ",
      "s_REAL_NAME_REVERS":"Zdeněk Matúš",
      "s_EMAIL":"zdenekmatus@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"539",
      "s_REAL_NAME":"Mayer Ivo",
      "s_REAL_NAME_REVERS":"Ivo Mayer",
      "s_EMAIL":"ivo.mayer@c-box.cz",
      "t_DESCRIPTION":"Od roku 1946 skautský vedoucí, čímž dosáhl dle svého přesvědčení velmi vysoké pedagogické kvalifikace. Před třídu se poprvé postavil v roce 1951, s chutí a láskou učil na  vesnických školách  až do  doby, kdy získával druhou svoji  nejvyšší kvalifikaci  kopáče na stavbě dálnice D1.  Tam ho poslali přátelé “vojáků v železných maringotkách”, s jejichž veliteli  měl v roce 1968 jako ředitel školy  dosti vážné rozpory. Po rehabilitaci a návratu do školství zažil nejkrásnější léta svého života v malé škole paní ředitelky Mgr. Evy Číhalové, které se podařilo vybudovat  na vesnici se 600 obyvateli nejen vynikající školu “pro děti”, ale i  vesnický  skautský oddíl, jehož  tehdejší členové dnes již sami vedou vynikající schůzky, výlety a tábory tábory nových bratrů a sester.  \tPro to vše je autor šťastným člověkem  a  jen někdy  je smutný z důvodů, ze kterých se právě vyznal.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"483",
      "s_REAL_NAME":"Mazáčová Nataša",
      "s_REAL_NAME_REVERS":"Nataša Mazáčová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"58",
      "s_REAL_NAME":"Mazánek Václav",
      "s_REAL_NAME_REVERS":"Václav Mazánek",
      "s_EMAIL":"bezhranic@bezhranic.de",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"999",
      "s_REAL_NAME":"Mediafax",
      "s_REAL_NAME_REVERS":"Mediafax",
      "s_EMAIL":"redakce@mediafax.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"919",
      "s_REAL_NAME":"Mejzlík, Štěpán ",
      "s_REAL_NAME_REVERS":"Štěpán Mejzlík,",
      "s_EMAIL":"mejzlik@english-online.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"566",
      "s_REAL_NAME":"Mertin Tomáš",
      "s_REAL_NAME_REVERS":"Tomáš Mertin",
      "s_EMAIL":"tmertin@hotmail.com",
      "t_DESCRIPTION":"Autor je studentem Gymnázia Nad Alejí v Praze.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"421",
      "s_REAL_NAME":"Mertin Václav",
      "s_REAL_NAME_REVERS":"Václav Mertin",
      "s_EMAIL":"mertinv@atlas.cz",
      "t_DESCRIPTION":"PhDr. Václav Mertin \npracuje na katedře psychologie Filozofické fakulty Univerzity Karlovy v Praze a současně je dětským psychologem v soukromé Pražské pedagogicko-psychologické poradně. Pravidelně publikuje v pedagogických periodikách.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"909",
      "s_REAL_NAME":"Mertl Jan",
      "s_REAL_NAME_REVERS":"Jan Mertl",
      "s_EMAIL":"jan.mertl@interbrigady.cz",
      "t_DESCRIPTION":"Pracuje jako metodik ICT a správce informačního systému ve školství již cca 10 let.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"37",
      "s_REAL_NAME":"Mezera Antonín",
      "s_REAL_NAME_REVERS":"Antonín Mezera",
      "s_EMAIL":"oppp8@volny.cz",
      "t_DESCRIPTION":"PhDr. Antonín Mezera (*1948), speciální pedagog, školní a poradenský psycholog. Je ředitelem pedagogicko-psychologické poradny, působil ve vedení České školní inspekce pro oblast speciálního školství,  od roku 1995 pak jako vedoucí odboru školství Magistrátu hl.m.Prahy a do roku 1999 jako náměstek ředitele Výzkumného ústavu pedagogického v Praze a vedoucí Centra pro hodnocení výsledků ve vzdělávání. Publikuje v odborných časopisech, vydal publikaci pro žáky se specifickou poruchu učení “Hravé čtení” a je autorem několika psychodiagnostických metod v oblasti psychologie školního chování. \n\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"769",
      "s_REAL_NAME":"Mgr. Petra Šobáňová",
      "s_REAL_NAME_REVERS":"Mgr. Petra Šobáňová",
      "s_EMAIL":"sobanovp@pdfnw.upol.cz",
      "t_DESCRIPTION":"Působí na Katedře výtvarné výchovy PdF UP v Olomouci a ve Studiu Experiment – estetika pro děti a mládež",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"737",
      "s_REAL_NAME":"MI ČR",
      "s_REAL_NAME_REVERS":"ČR MI",
      "s_EMAIL":"posta@micr.cz",
      "t_DESCRIPTION":"Ministerstvo informatiky ČR",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"785",
      "s_REAL_NAME":"Mičienka, Marek",
      "s_REAL_NAME_REVERS":"Marek Mičienka,",
      "s_EMAIL":"micienka@partnersczech.cz",
      "t_DESCRIPTION":"Koordinátor a lektor projektu ROZUMĚT MÉDIÍM.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"461",
      "s_REAL_NAME":"Milan Hausner Vít Šebor,",
      "s_REAL_NAME_REVERS":"Milan Hausner Vít Šebor,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"772",
      "s_REAL_NAME":"Mitáček, Zdeněk",
      "s_REAL_NAME_REVERS":"Zdeněk Mitáček,",
      "s_EMAIL":"redakce@jazyky.com",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"762",
      "s_REAL_NAME":"Mižoch, Lukáš",
      "s_REAL_NAME_REVERS":"Lukáš Mižoch,",
      "s_EMAIL":"net@mizoch.net",
      "t_DESCRIPTION":"Asistent výpočetní techniky,  SPŠ chemická akademika Heyrovského a Gymnázium, Ostrava",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"986",
      "s_REAL_NAME":"Mleziva, Jan-Michal ",
      "s_REAL_NAME_REVERS":"Jan-Michal Mleziva,",
      "s_EMAIL":"mleziva@centrum.cz",
      "t_DESCRIPTION":"Iniciátor petic za změnu školského zákona a Rámcového vzdělávacího programu pro základní vzdělávání.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"768",
      "s_REAL_NAME":"Molčan, Filip",
      "s_REAL_NAME_REVERS":"Filip Molčan,",
      "s_EMAIL":"fipa@mylinux.cz",
      "t_DESCRIPTION":"- Zakladatel a předseda sdružení OSS Alliance\n- Člen českého lokalizačního týmu OpenOffice.org\n- Člen projektu czilla.cz - testování produktů Mozilla pod Apple MacOS X\n- Člen Českého spolku uživatelů operačního systému IBM OS\/2\n- Člen CZLUGu - Sdružení uživatelů Linuxu\n- Člen M3UG - Sdružení uživatelů MacOS\n- Zakladatel mezinárodního serveru o systému IBM OS\/2 - OS\/2.cz\n- Člen odborné skupiny Ministerstva informatiky pro služby infrastruktury IDABC\n- Spoluzakladatel a ředitel společnosti blue.point Solutions, s. r. o., která se věnuje především Open Source řešením a tvorbě webových aplikací.\n- Externí spolupracovník Živě.cz, Tiscali.cz, iDNES, časopisů Computer, e-biz.\n- Externí spolupracovník projektu COSPA - Consortium for Open Source in the Public Administration při Evropském parlamentu.\n- Člen mezinárodní organizace The Open Document Fellowship.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"759",
      "s_REAL_NAME":"Moravcová, MUDr. Alexandra ",
      "s_REAL_NAME_REVERS":"Moravcová, MUDr. Alexandra",
      "s_EMAIL":"detske@lf1.cuni.cz",
      "t_DESCRIPTION":"Dětská obezitoložka a endokrinoložka, Klinika dětského a dorostového lékařství VFN, Praha",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"434",
      "s_REAL_NAME":"Morávková Alena",
      "s_REAL_NAME_REVERS":"Alena Morávková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"23",
      "s_REAL_NAME":"Morkes David",
      "s_REAL_NAME_REVERS":"David Morkes",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Ing. David Morkes (*1972)\nVystudoval Fakultu jadernou a fyzikálně inženýrskou ČVUT v Praze. 3 roky\npracoval jsko vývojový inženýr, v současné době je internetovým a\nintranetovým programátorem ve Všeobecné stavební spořitelně Komerční banky\na. s. Ve spolupráci s nakladatelstvím Computer Press publikuje učebnice a\nodborné manuály zaměřené na programování a ovládání počítačových aplikací.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"21",
      "s_REAL_NAME":"Morkes František",
      "s_REAL_NAME_REVERS":"František Morkes",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"391",
      "s_REAL_NAME":"Mrázková Anna",
      "s_REAL_NAME_REVERS":"Anna Mrázková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"645",
      "s_REAL_NAME":"MŠMT",
      "s_REAL_NAME_REVERS":"MŠMT",
      "s_EMAIL":"Ondrej.Gabriel@msmt.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"610",
      "s_REAL_NAME":"Mudrák David",
      "s_REAL_NAME_REVERS":"David Mudrák",
      "s_EMAIL":"david.mudrak@centrum.cz",
      "t_DESCRIPTION":"Autor působí na Pedagogická fakultě Univerzity Karlovy v Praze. ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"910",
      "s_REAL_NAME":"Müllerová, Alena",
      "s_REAL_NAME_REVERS":"Alena Müllerová,",
      "s_EMAIL":"alena.mullerova@unob.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"902",
      "s_REAL_NAME":"Musil, Josef",
      "s_REAL_NAME_REVERS":"Josef Musil,",
      "s_EMAIL":"zsdalovice@dragon.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"722",
      "s_REAL_NAME":"Musílek, Michal",
      "s_REAL_NAME_REVERS":"Michal Musílek,",
      "s_EMAIL":"Michal.Musilek@seznam.cz",
      "t_DESCRIPTION":"Střední zdravotnická škola a Vyšší zdravotnická škola, Komenského 234, 500 03 Hradec Králové",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"837",
      "s_REAL_NAME":"Myslín, Josef",
      "s_REAL_NAME_REVERS":"Josef Myslín,",
      "s_EMAIL":"myslin@volny.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"748",
      "s_REAL_NAME":"Nachtmann, Petr",
      "s_REAL_NAME_REVERS":"Petr Nachtmann,",
      "s_EMAIL":"petr.nachtmann@seznam.cz",
      "t_DESCRIPTION":"ICT konzultant publikující na serverech iDNES, Telnet, Britské listy, LUPA a další",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"915",
      "s_REAL_NAME":"Nádvorník Jaroslav ",
      "s_REAL_NAME_REVERS":"Jaroslav Nádvorník",
      "s_EMAIL":"j.nadvornik@propojeni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"894",
      "s_REAL_NAME":"NAEP",
      "s_REAL_NAME_REVERS":"NAEP",
      "s_EMAIL":"silvie.pychova@naep.cz",
      "t_DESCRIPTION":"Národní agentura pro evropské vzdělávací programy",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"717",
      "s_REAL_NAME":"Naske Petr",
      "s_REAL_NAME_REVERS":"Petr Naske",
      "s_EMAIL":"naske@zscvrch.cz",
      "t_DESCRIPTION":"Základní škola Červený Vrch, Alžírská 680, 160 00 Praha 6",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"929",
      "s_REAL_NAME":"NCDiV",
      "s_REAL_NAME_REVERS":"NCDiV",
      "s_EMAIL":"Slemendova@csvs.cz",
      "t_DESCRIPTION":"Centrum pro studium vysokého školství - Národní centrum distančního vzdělávání",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"926",
      "s_REAL_NAME":"Neff, Ondřej",
      "s_REAL_NAME_REVERS":"Ondřej Neff,",
      "s_EMAIL":"ondrejneff@gmail.com",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"565",
      "s_REAL_NAME":"Nešpor Martin",
      "s_REAL_NAME_REVERS":"Martin Nešpor",
      "s_EMAIL":"nespormartin@post.cz",
      "t_DESCRIPTION":"Autor působí jako pedagog na Základní církevní škole sester voršilek v Olomouci.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"628",
      "s_REAL_NAME":"Netušil Pavel",
      "s_REAL_NAME_REVERS":"Pavel Netušil",
      "s_EMAIL":"panet@seznam.cz",
      "t_DESCRIPTION":"Autor působí na základní škole.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"917",
      "s_REAL_NAME":"Neugebauer Tomáš ",
      "s_REAL_NAME_REVERS":"Tomáš Neugebauer",
      "s_EMAIL":"tomas.neugebauer@vfn.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"441",
      "s_REAL_NAME":"Neumajer Ondřej",
      "s_REAL_NAME_REVERS":"Ondřej Neumajer",
      "s_EMAIL":"ondrej@neumajer.cz",
      "t_DESCRIPTION":"Ondřej Neumajer se dlouhodobě věnuje problematice využit&iacute; informačn&iacute;ch a komunikačn&iacute;ch technologi&iacute; ve vzděl&aacute;v&aacute;n&iacute;. Jeho osobn&iacute; domovsk&aacute; str&aacute;nka je dostupn&aacute; na adrese <A HREF=\"http:\/\/ondrej.neumajer.cz\/\">http:\/\/ondrej.neumajer.cz\/<\/A>.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"677",
      "s_REAL_NAME":"Neužilovi Milada a Jaromír",
      "s_REAL_NAME_REVERS":"Neužilovi Milada a Jaromír",
      "s_EMAIL":"mj.neuzilovi@tiscali.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"852",
      "s_REAL_NAME":"Nezvalová, Danuše",
      "s_REAL_NAME_REVERS":"Danuše Nezvalová,",
      "s_EMAIL":"rvpmaster@rvp.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"989",
      "s_REAL_NAME":"NICM",
      "s_REAL_NAME_REVERS":"NICM",
      "s_EMAIL":"icm@adam.cz",
      "t_DESCRIPTION":"Oddělení informací a Národní informační centrum pro mládež Národního institutu dětí a mládeže MŠMT",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"832",
      "s_REAL_NAME":"NIDM",
      "s_REAL_NAME_REVERS":"NIDM",
      "s_EMAIL":"info@nidm.cz",
      "t_DESCRIPTION":"Národní institut dětí a mládeže (NIDM) Ministerstva školství, mládeže a tělovýchovy (MŠMT) ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"826",
      "s_REAL_NAME":"NIDV",
      "s_REAL_NAME_REVERS":"NIDV",
      "s_EMAIL":"info@nidv.cz",
      "t_DESCRIPTION":"Národní institut dalšího vzdělávání",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"455",
      "s_REAL_NAME":"Nitschová Daniela",
      "s_REAL_NAME_REVERS":"Daniela Nitschová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Autorka působí v Pedagogicko-psychologické poradně v České Lípě.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"751",
      "s_REAL_NAME":"Nosreti, Darius",
      "s_REAL_NAME_REVERS":"Darius Nosreti,",
      "s_EMAIL":"info@darius.cz",
      "t_DESCRIPTION":"Nezávislý publicista a filmový režisér.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"761",
      "s_REAL_NAME":"Nováčková, Jana",
      "s_REAL_NAME_REVERS":"Jana Nováčková,",
      "s_EMAIL":"jana.novackova@volny.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"547",
      "s_REAL_NAME":"Novák Michal",
      "s_REAL_NAME_REVERS":"Michal Novák",
      "s_EMAIL":"spec.pedagog@seznam.cz",
      "t_DESCRIPTION":"Autor působí jako speciální pedagog na ZŠ Svážná v Brně.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"990",
      "s_REAL_NAME":"Novák, Filip",
      "s_REAL_NAME_REVERS":"Filip Novák,",
      "s_EMAIL":"novak@planina.cz",
      "t_DESCRIPTION":"Ředitel ZŠ a Gymnázia Milady Horákové, Praha 4.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"747",
      "s_REAL_NAME":"Novák, Pavel",
      "s_REAL_NAME_REVERS":"Pavel Novák,",
      "s_EMAIL":"pavelknovak@yahoo.com",
      "t_DESCRIPTION":"Učitel na SPŠE a správce sítě.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"699",
      "s_REAL_NAME":"Nováková Martina",
      "s_REAL_NAME_REVERS":"Martina Nováková",
      "s_EMAIL":"portal@portal.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"987",
      "s_REAL_NAME":"noviny, Literární",
      "s_REAL_NAME_REVERS":"Literární noviny,",
      "s_EMAIL":"redakce@literarky.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"643",
      "s_REAL_NAME":"Novotný Jiří",
      "s_REAL_NAME_REVERS":"Jiří Novotný",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"552",
      "s_REAL_NAME":"Novotný Petr ",
      "s_REAL_NAME_REVERS":"Petr Novotný",
      "s_EMAIL":"novotny@phil.muni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"961",
      "s_REAL_NAME":"Novotný, Ota",
      "s_REAL_NAME_REVERS":"Ota Novotný,",
      "s_EMAIL":"novotnyo@vse.cz",
      "t_DESCRIPTION":"Katedra informačních technologií  VŠE v Praze",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"573",
      "s_REAL_NAME":"NÚOV",
      "s_REAL_NAME_REVERS":"NÚOV",
      "s_EMAIL":"nuov@nuov.cz",
      "t_DESCRIPTION":"Národní ústav odborného vzdělávání",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"479",
      "s_REAL_NAME":"Nygrýn Pavel",
      "s_REAL_NAME_REVERS":"Pavel Nygrýn",
      "s_EMAIL":"pavel.nygryn@cpress.cz",
      "t_DESCRIPTION":"Autor je redaktorem časopisu Computer.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"595",
      "s_REAL_NAME":"Nymš Jan ",
      "s_REAL_NAME_REVERS":"Jan Nymš",
      "s_EMAIL":"admin@spssoutu.cz",
      "t_DESCRIPTION":"Autor je správcem rozsáhlé školní počítačové sítě.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"641",
      "s_REAL_NAME":"Obst Otto",
      "s_REAL_NAME_REVERS":"Otto Obst",
      "s_EMAIL":"obst@pdfnw.upol.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"621",
      "s_REAL_NAME":"Odehnal Martin",
      "s_REAL_NAME_REVERS":"Martin Odehnal",
      "s_EMAIL":"odehnalmartin@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"833",
      "s_REAL_NAME":"Odehnalová,  Lenka",
      "s_REAL_NAME_REVERS":"Lenka Odehnalová,",
      "s_EMAIL":"sibova@vuppraha.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"394",
      "s_REAL_NAME":"Ogrodník Zdeněk",
      "s_REAL_NAME_REVERS":"Zdeněk Ogrodník",
      "s_EMAIL":"zdenek.ogrodnik@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"555",
      "s_REAL_NAME":"Ogrodník Zdeněk st.",
      "s_REAL_NAME_REVERS":"Ogrodník Zdeněk st.",
      "s_EMAIL":"zdenek.ogrodnik@atlas.cz",
      "t_DESCRIPTION":"Autor je ředitelem základní školy.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"970",
      "s_REAL_NAME":"Olmer, Petr",
      "s_REAL_NAME_REVERS":"Petr Olmer,",
      "s_EMAIL":"petr@olmer.cz",
      "t_DESCRIPTION":"Autor už není to, co kdysi.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"818",
      "s_REAL_NAME":"Ondřej Jakubčík",
      "s_REAL_NAME_REVERS":"Jakubčík Ondřej",
      "s_EMAIL":"ojakubcik@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"55",
      "s_REAL_NAME":"Ondroušková Eva",
      "s_REAL_NAME_REVERS":"Eva Ondroušková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"863",
      "s_REAL_NAME":"OSF",
      "s_REAL_NAME_REVERS":"OSF",
      "s_EMAIL":"zdenka.almerova@osf.cz",
      "t_DESCRIPTION":"Nadace Open Society Fund Praha, Seifertova 47, 130 00 Praha 3",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"617",
      "s_REAL_NAME":"Otakar Schön",
      "s_REAL_NAME_REVERS":"Schön Otakar",
      "s_EMAIL":"otakar.schon@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"787",
      "s_REAL_NAME":"Ott, Vlastimil",
      "s_REAL_NAME_REVERS":"Vlastimil Ott,",
      "s_EMAIL":"vlastimil.ott@linuxexpres.cz",
      "t_DESCRIPTION":"Je povoláním učitel češtiny a němčiny na střední škole. Linux zná od roku 1999 a dnes je jeho stále spokojenějším uživatelem. Pracuje v redakci časopisu LinuxEXPRES.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"60",
      "s_REAL_NAME":"Palacká Anna",
      "s_REAL_NAME_REVERS":"Anna Palacká",
      "s_EMAIL":"palacka@post.cz",
      "t_DESCRIPTION":"Ing. arch. Anna Palacká je ředitelkou Sdružení Manus, zabývá se prací se zrakově postiženými studenty.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"562",
      "s_REAL_NAME":"Palata Vlastimil",
      "s_REAL_NAME_REVERS":"Vlastimil Palata",
      "s_EMAIL":"info@acol.cz",
      "t_DESCRIPTION":"Autor je ředitelem AutoContu On Line, a.s.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"563",
      "s_REAL_NAME":"Parma Pavel",
      "s_REAL_NAME_REVERS":"Pavel Parma",
      "s_EMAIL":"info@acol.cz",
      "t_DESCRIPTION":"Autor je obchodním ředitelem společnosti AutoCont On Line, a.s.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"903",
      "s_REAL_NAME":"Pastyříková,Jana ",
      "s_REAL_NAME_REVERS":"Pastyříková,Jana",
      "s_EMAIL":"jpastyrikova@2zszdar.cz",
      "t_DESCRIPTION":"Základní škola Komenského 2, 591 01 Žďár nad Sázavou; Tel.: 566 625 515",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"688",
      "s_REAL_NAME":"Pauchly Karol",
      "s_REAL_NAME_REVERS":"Karol Pauchly",
      "s_EMAIL":"flatulent@szm.com",
      "t_DESCRIPTION":"PaedDr. Karol Pauchly vyučuje na ZŠ s MŠ Chlebnice na Oravě.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"521",
      "s_REAL_NAME":"Pavel Knobloch David Hawiger,",
      "s_REAL_NAME_REVERS":"Pavel Knobloch David Hawiger,",
      "s_EMAIL":"zlenice@horackova.cz",
      "t_DESCRIPTION":"Autoři jsou členy a organizátory Zlenické iniciativy učitelů informatiky.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"508",
      "s_REAL_NAME":"Pavelka Cyril",
      "s_REAL_NAME_REVERS":"Cyril Pavelka",
      "s_EMAIL":"cpa@volny.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"851",
      "s_REAL_NAME":"Pávišová, Zina",
      "s_REAL_NAME_REVERS":"Zina Pávišová,",
      "s_EMAIL":"rvpmaster@rvp.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"383",
      "s_REAL_NAME":"Pavlíčková Mirka",
      "s_REAL_NAME_REVERS":"Mirka Pavlíčková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"567",
      "s_REAL_NAME":"Pečenka Petr ",
      "s_REAL_NAME_REVERS":"Petr Pečenka",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"480",
      "s_REAL_NAME":"Pecinovský Rudolf",
      "s_REAL_NAME_REVERS":"Rudolf Pecinovský",
      "s_EMAIL":"rudolf@pecinovsky.cz",
      "t_DESCRIPTION":"Rudolf Pecinovský pravidelně publikuje v technických časopisech, je autorem nebo spoluautorem více jak třiceti odborných publikací včetně učebnic programování a informatiky pro základní školy.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"578",
      "s_REAL_NAME":"Pekařová Ivana",
      "s_REAL_NAME_REVERS":"Ivana Pekařová",
      "s_EMAIL":"ivana.pekarova@vslib.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"672",
      "s_REAL_NAME":"Pelka František",
      "s_REAL_NAME_REVERS":"František Pelka",
      "s_EMAIL":"pelka@idm-msmt.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"853",
      "s_REAL_NAME":"Pernicová, Hana",
      "s_REAL_NAME_REVERS":"Hana Pernicová,",
      "s_EMAIL":"rvpmaster@rvp.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"518",
      "s_REAL_NAME":"Peterka Jiří",
      "s_REAL_NAME_REVERS":"Jiří Peterka",
      "s_EMAIL":"jiri@peterka.cz",
      "t_DESCRIPTION":"Autor je volný novinář. Archiv jeho článku naleznete http:\/\/archiv.czech.net",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"512",
      "s_REAL_NAME":"Peterka ml. Jiří",
      "s_REAL_NAME_REVERS":"Peterka ml. Jiří",
      "s_EMAIL":"jirka@peterka.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"47",
      "s_REAL_NAME":"Petlák Erich",
      "s_REAL_NAME_REVERS":"Erich Petlák",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"935",
      "s_REAL_NAME":"Petříček, Miroslav ",
      "s_REAL_NAME_REVERS":"Miroslav Petříček,",
      "s_EMAIL":"m.petricek@post.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"489",
      "s_REAL_NAME":"Petro Jozef",
      "s_REAL_NAME_REVERS":"Jozef Petro",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"992",
      "s_REAL_NAME":"Petrovská, Kamila",
      "s_REAL_NAME_REVERS":"Kamila Petrovská,",
      "s_EMAIL":"editor@rvp.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"695",
      "s_REAL_NAME":"Peutelschmiedová Alžběta",
      "s_REAL_NAME_REVERS":"Alžběta Peutelschmiedová",
      "s_EMAIL":"peutel@pdfnw.upol.cz",
      "t_DESCRIPTION":"Doc. PaedDr. Alžběta Peutelschmiedová, Ph.D., působí na katedře speciální pedagogiky PdF UPOL. Je autorkou knih a mnoha článků o koktavosti.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"472",
      "s_REAL_NAME":"Piškula Martin",
      "s_REAL_NAME_REVERS":"Martin Piškula",
      "s_EMAIL":"piskula@mironet.cz",
      "t_DESCRIPTION":"Autor je odborným redaktorem serveru ZASTUDENA.cz, který se specializuje na problematiku autorského práva.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"503",
      "s_REAL_NAME":"Pitner Tomáš",
      "s_REAL_NAME_REVERS":"Tomáš Pitner",
      "s_EMAIL":"tomp@informatics.muni.cz",
      "t_DESCRIPTION":"Autor působí na Fakultě informatiky, byl členem přípravného týmu SIPVZ a Řídicího kolegia Programu I - Informační gramotnost.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"855",
      "s_REAL_NAME":"Plesná Ludmila",
      "s_REAL_NAME_REVERS":"Ludmila Plesná",
      "s_EMAIL":"lida.plesna@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"951",
      "s_REAL_NAME":"Podracký, Vlastimil ",
      "s_REAL_NAME_REVERS":"Vlastimil Podracký,",
      "s_EMAIL":"info@konzervativnistrana.cz",
      "t_DESCRIPTION":"Člen Předsednictva Konzervativní strany",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"44",
      "s_REAL_NAME":"Podroužek Vladimír",
      "s_REAL_NAME_REVERS":"Vladimír Podroužek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"611",
      "s_REAL_NAME":"Podskubková Jarka ",
      "s_REAL_NAME_REVERS":"Jarka Podskubková",
      "s_EMAIL":"jarkapod@hotmail.com",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"694",
      "s_REAL_NAME":"Poduška Ondřej",
      "s_REAL_NAME_REVERS":"Ondřej Poduška",
      "s_EMAIL":"Ondrej.Poduska@clovekvtisni.cz",
      "t_DESCRIPTION":"Autor pracuje ve společnosti Člověk v tísni.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"952",
      "s_REAL_NAME":"Pokorná, Marie",
      "s_REAL_NAME_REVERS":"Marie Pokorná,",
      "s_EMAIL":"pokorna@gymspgs.cz",
      "t_DESCRIPTION":"Gymnázium a Střední odborná škola pedagogická, Pontassievská 3, 669 02 Znojmo; Tel.: 515 225 529",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"966",
      "s_REAL_NAME":"Pokorný, Lukáš",
      "s_REAL_NAME_REVERS":"Lukáš Pokorný,",
      "s_EMAIL":"lukas_pokorny@hotmail.com",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"554",
      "s_REAL_NAME":"Pol Milan",
      "s_REAL_NAME_REVERS":"Milan Pol",
      "s_EMAIL":"pol@phil.muni.cz",
      "t_DESCRIPTION":"Autor je vedoucím Ústavu pedagogických věd FF MU Brno.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"593",
      "s_REAL_NAME":"Poláček Jiří",
      "s_REAL_NAME_REVERS":"Jiří Poláček",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"706",
      "s_REAL_NAME":"Polák Milan",
      "s_REAL_NAME_REVERS":"Milan Polák",
      "s_EMAIL":"polinm@seznam.cz",
      "t_DESCRIPTION":"Autor působí na Univerzitě Palackého v Olomouci.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"802",
      "s_REAL_NAME":"Polášek, Radim",
      "s_REAL_NAME_REVERS":"Radim Polášek,",
      "s_EMAIL":"radim.polasek@centrum.cz",
      "t_DESCRIPTION":"Katedra technické a informační výchovy, Pedagogická fakulta, Univerzita Palackého, Žižkovo nám. 5, 771 40 Olomouc; Tel.: 585 635 292",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"457",
      "s_REAL_NAME":"Polechová Pavla",
      "s_REAL_NAME_REVERS":"Pavla Polechová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"RNDr. Pavla Polechová působí na Pedagogické fakultě UK Praha, ÚVRŠ.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"570",
      "s_REAL_NAME":"Politzer Michal ",
      "s_REAL_NAME_REVERS":"Michal Politzer",
      "s_EMAIL":"michal.politzer@cpress.cz",
      "t_DESCRIPTION":"šéfredaktor časopisu Computer",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"49",
      "s_REAL_NAME":"Pollak Jiří W.",
      "s_REAL_NAME_REVERS":"Pollak Jiří W.",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"652",
      "s_REAL_NAME":"Polzer Jan ",
      "s_REAL_NAME_REVERS":"Jan Polzer",
      "s_EMAIL":"jan.polzer@cpress.cz",
      "t_DESCRIPTION":"Redaktor časopisu Computer",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"50",
      "s_REAL_NAME":"Popelková Šárka",
      "s_REAL_NAME_REVERS":"Šárka Popelková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"29",
      "s_REAL_NAME":"Pospíšil Miroslav",
      "s_REAL_NAME_REVERS":"Miroslav Pospíšil",
      "s_EMAIL":"ceskaskola@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"974",
      "s_REAL_NAME":"Pouzar, Miloslav",
      "s_REAL_NAME_REVERS":"Miloslav Pouzar,",
      "s_EMAIL":"milan.pouzar@upce.cz",
      "t_DESCRIPTION":"Univerzita Pardubice, Ústav ochrany životního prostředí, Laboratoř atomové spektrometrie",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"602",
      "s_REAL_NAME":"Povolný Aleš",
      "s_REAL_NAME_REVERS":"Aleš Povolný",
      "s_EMAIL":"redakce@ucitelske-listy.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"683",
      "s_REAL_NAME":"Prášilová Michaela",
      "s_REAL_NAME_REVERS":"Michaela Prášilová",
      "s_EMAIL":"prasilov@pdfnw.upol.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"689",
      "s_REAL_NAME":"Pravec David",
      "s_REAL_NAME_REVERS":"David Pravec",
      "s_EMAIL":"alekibango@danix.cz",
      "t_DESCRIPTION":"Bc. David Pravec je zakladatelem a hlavním vývojářem projektu Danix (www.danix.cz).",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"723",
      "s_REAL_NAME":"Preisler, Daniel",
      "s_REAL_NAME_REVERS":"Daniel Preisler,",
      "s_EMAIL":"preisler@zs-tgm.cz",
      "t_DESCRIPTION":"ZŠ T.G.Masaryka, Palackého 535, 407 21 Česká Kamenice",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"968",
      "s_REAL_NAME":"Přichystalová, Ivana ",
      "s_REAL_NAME_REVERS":"Ivana Přichystalová,",
      "s_EMAIL":"iprichystalova@seznam.cz",
      "t_DESCRIPTION":"Jabloňany 100, 679 01 Skalice nad Svitavou ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"15",
      "s_REAL_NAME":"Procházka Michal",
      "s_REAL_NAME_REVERS":"Michal Procházka",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"664",
      "s_REAL_NAME":"Procházková Ivana",
      "s_REAL_NAME_REVERS":"Ivana Procházková",
      "s_EMAIL":"prochazkova@czesha.cz",
      "t_DESCRIPTION":"Ivana Procházková pracovala v letech 1996-2001 v ÚIV jako analytik a člen Národního koordinačního centra mezinárodních výzkumů OECD\/PISA a IEA\/TIMSS, TIMSS-R, TIMSS-Videostudy a Sites v České republice, od roku 1998 pak jako národní koordinátorka výzkumů IEA\/CivEd a PIRLS. V letech 2002-2003 pracovala jako analytik ve Středisku vzdělávací politiky při Pedagogické fakultě UK v Praze.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"897",
      "s_REAL_NAME":"Procházková, Lucie ",
      "s_REAL_NAME_REVERS":"Lucie Procházková,",
      "s_EMAIL":"prochazkoval@vup­praha.cz ",
      "t_DESCRIPTION":"Výzkumný ústav pedagogický v Praze, 1. výzkumná skupina pedagogika a didaktika všeobecného vzdělávání, oddělení srovnávací pedagogiky a pedagogických výzkumů",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"420",
      "s_REAL_NAME":"Prokešová Hana",
      "s_REAL_NAME_REVERS":"Hana Prokešová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"PhDr. Hana Prokešová pracovala jako dětský klinický psycholog, v současné době působí v pedagogicko - psychologické poradně v Praze. Je členem o.s. Acorus - centrum pro domácí násilí. Mimo jiné se zabývá preventivními  programy psychopatogenních jevů a skupinovou psychoterapií.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"712",
      "s_REAL_NAME":"Prokešová Světla",
      "s_REAL_NAME_REVERS":"Světla Prokešová",
      "s_EMAIL":"prokesova@csicr.cz",
      "t_DESCRIPTION":"Autorka je pracovnicí České školské inspekce.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"511",
      "s_REAL_NAME":"Průcha Jan",
      "s_REAL_NAME_REVERS":"Jan Průcha",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"907",
      "s_REAL_NAME":"PSP",
      "s_REAL_NAME_REVERS":"PSP",
      "s_EMAIL":"posta@psp.cz",
      "t_DESCRIPTION":"Poslanecká sněmovna Parlamentu ČR",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"592",
      "s_REAL_NAME":"Pudivítr Petr",
      "s_REAL_NAME_REVERS":"Petr Pudivítr",
      "s_EMAIL":"puda@seznam.cz",
      "t_DESCRIPTION":"Autor je doktorand Astronomického ústavu MFF UK.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"668",
      "s_REAL_NAME":"Punar Tomáš",
      "s_REAL_NAME_REVERS":"Tomáš Punar",
      "s_EMAIL":"punar@mail.muni.cz",
      "t_DESCRIPTION":"Autor je studentem FSS MU a FF MU v Brně.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"886",
      "s_REAL_NAME":"Rabušicová, Milada",
      "s_REAL_NAME_REVERS":"Milada Rabušicová,",
      "s_EMAIL":"milada@phil.muni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"716",
      "s_REAL_NAME":"Rak Josef",
      "s_REAL_NAME_REVERS":"Josef Rak",
      "s_EMAIL":"peparak@volny.cz ",
      "t_DESCRIPTION":"Gymnázium Pardubice, Dašická 1083, 530 03 Pardubice; telefon 466 650 715",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"509",
      "s_REAL_NAME":"Rakušan Zdeněk",
      "s_REAL_NAME_REVERS":"Zdeněk Rakušan",
      "s_EMAIL":"zdenek.rakusan@email.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"386",
      "s_REAL_NAME":"Rambousková Bohdana",
      "s_REAL_NAME_REVERS":"Bohdana Rambousková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"733",
      "s_REAL_NAME":"Rangl Martin ",
      "s_REAL_NAME_REVERS":"Martin Rangl",
      "s_EMAIL":"rangl.m@gym-bohumin.cz",
      "t_DESCRIPTION":"Gymnázium Františka Živného Bohumín\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"11",
      "s_REAL_NAME":"redakce ",
      "s_REAL_NAME_REVERS":"redakce",
      "s_EMAIL":"vit.sebor@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"500",
      "s_REAL_NAME":"redakce SME\/",
      "s_REAL_NAME_REVERS":"SME\/ redakce",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"528",
      "s_REAL_NAME":"Řeháček David",
      "s_REAL_NAME_REVERS":"David Řeháček",
      "s_EMAIL":"david.rehacek@cpress.cz",
      "t_DESCRIPTION":"Autor je šéfredaktorem časopisu Computer Design.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"972",
      "s_REAL_NAME":"RESPEKT",
      "s_REAL_NAME_REVERS":"RESPEKT",
      "s_EMAIL":"redakce@respekt.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"825",
      "s_REAL_NAME":"Řídká, Eva",
      "s_REAL_NAME_REVERS":"Eva Řídká,",
      "s_EMAIL":"ridka@cermat.cz",
      "t_DESCRIPTION":"Koordinátorka matematiky v Centru pro zjišťování výsledků vzdělávání",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"20",
      "s_REAL_NAME":"Rohan Jiří",
      "s_REAL_NAME_REVERS":"Jiří Rohan",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"704",
      "s_REAL_NAME":"Rohlíková Lucie",
      "s_REAL_NAME_REVERS":"Lucie Rohlíková",
      "s_EMAIL":"lrohlik@ucv.zcu.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"827",
      "s_REAL_NAME":"Rosecká, Zdena",
      "s_REAL_NAME_REVERS":"Zdena Rosecká,",
      "s_EMAIL":"info@tvorivaskola.cz",
      "t_DESCRIPTION":"Autorka myšlenky tvořivé školy",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"580",
      "s_REAL_NAME":"Rosecký Čeněk",
      "s_REAL_NAME_REVERS":"Čeněk Rosecký",
      "s_EMAIL":"tvoriva_skola@volny.cz",
      "t_DESCRIPTION":"Autor je lektorem vzdělávacího programu Tvořivá škola (www.tvorivaskola.cz).",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"596",
      "s_REAL_NAME":"Rosolová Kamila ",
      "s_REAL_NAME_REVERS":"Kamila Rosolová",
      "s_EMAIL":"redakce@ucitelske-listy.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"465",
      "s_REAL_NAME":"Roubal Pavel",
      "s_REAL_NAME_REVERS":"Pavel Roubal",
      "s_EMAIL":"pavelroubal@centrum.cz",
      "t_DESCRIPTION":"Autor je učitelem VT a správce sítě na Gymnáziu v Pacově.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"414",
      "s_REAL_NAME":"Rubánková Petra",
      "s_REAL_NAME_REVERS":"Petra Rubánková",
      "s_EMAIL":"rubankov@uiv.cz",
      "t_DESCRIPTION":"Mgr. Petra Rubánková (*1970), vystudovala FF UK v Praze obor pedagogika, sociologie. Zabývá se zejména problematikou hodnocení výsledků vzdělávání, tvorbou testů. Pracovala na České školní inspekci, ve Výzkumném ústavu pedagogickém, nyní v Centru pro reformu maturitní zkoušky (CERMAT).",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"642",
      "s_REAL_NAME":"Rusek Ondřej",
      "s_REAL_NAME_REVERS":"Ondřej Rusek",
      "s_EMAIL":"rusek@gybon.cz",
      "t_DESCRIPTION":"Autor působí na Gymnáziu Boženy Němcové v Hradci Králové.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"654",
      "s_REAL_NAME":"Růžičková Markéta",
      "s_REAL_NAME_REVERS":"Markéta Růžičková",
      "s_EMAIL":"ruzickova@nuov.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"684",
      "s_REAL_NAME":"Rýdl Karel",
      "s_REAL_NAME_REVERS":"Karel Rýdl",
      "s_EMAIL":"rydl@cbox.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"867",
      "s_REAL_NAME":"Rylich, Jan ",
      "s_REAL_NAME_REVERS":"Jan Rylich,",
      "s_EMAIL":"J.Rylich@seznam.cz",
      "t_DESCRIPTION":"Studia nových médií, elektronický časopis Ikaros",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"911",
      "s_REAL_NAME":"Ryška Radim",
      "s_REAL_NAME_REVERS":"Radim Ryška",
      "s_EMAIL":"ryskar@uvrs.pedf.cuni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"735",
      "s_REAL_NAME":"Sak, Petr",
      "s_REAL_NAME_REVERS":"Petr Sak,",
      "s_EMAIL":"sak@mbox.dkm.cz",
      "t_DESCRIPTION":"PhDr. Petr Sak, CSc, je sociolog",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"56",
      "s_REAL_NAME":"Šalanda Marek",
      "s_REAL_NAME_REVERS":"Marek Šalanda",
      "s_EMAIL":"salanda@cpress.cz",
      "t_DESCRIPTION":"Mgr. Marek Šalanda\n(*1975) vystudoval geografii na Přírodovědecké a historii na Filozofické fakultě Masarykovy univerzity. V rámci studia vystudoval i pedagogiku a dydaktiku pro SŠ. Dnes je redaktorem časopisu Computer a zabývá se především softwarem a jeho využitím.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"813",
      "s_REAL_NAME":"Šamánek, Jan ",
      "s_REAL_NAME_REVERS":"Jan Šamánek,",
      "s_EMAIL":"jan.samanek@deviceglobal.com",
      "t_DESCRIPTION":"Country manager společnosti Device Automation Czech, spol. s.r.o.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"876",
      "s_REAL_NAME":"Sangiorgi, Daniele ",
      "s_REAL_NAME_REVERS":"Daniele Sangiorgi,",
      "s_EMAIL":"daniele.sangiorgi@aster.it",
      "t_DESCRIPTION":"ASTER S. Cons. p. a.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"439",
      "s_REAL_NAME":"Sárközi Radek",
      "s_REAL_NAME_REVERS":"Radek Sárközi",
      "s_EMAIL":"sarkozi@volny.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"451",
      "s_REAL_NAME":"Šátková Naděžda",
      "s_REAL_NAME_REVERS":"Naděžda Šátková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"714",
      "s_REAL_NAME":"Šauerová Ivana",
      "s_REAL_NAME_REVERS":"Ivana Šauerová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Gymnázium Pardubice",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"30",
      "s_REAL_NAME":"Saxonberg Steven",
      "s_REAL_NAME_REVERS":"Steven Saxonberg",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"496",
      "s_REAL_NAME":"Schincke Jiří",
      "s_REAL_NAME_REVERS":"Jiří Schincke",
      "s_EMAIL":"schincke@post.cz",
      "t_DESCRIPTION":"PaedDr. Jiří Schincke vyučuje na základní škole ve Zlíně.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"782",
      "s_REAL_NAME":"Schlemmer, Martin ",
      "s_REAL_NAME_REVERS":"Martin Schlemmer,",
      "s_EMAIL":"martin.schlemmer@glosy.inf",
      "t_DESCRIPTION":" Student politologie na FSV UK, šéfredaktor <A HREF=\"http:\/\/glosy.info\/\">http:\/\/glosy.info<\/A> ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"618",
      "s_REAL_NAME":"Schön Otakar",
      "s_REAL_NAME_REVERS":"Otakar Schön",
      "s_EMAIL":"otakar.schon@seznam.cz",
      "t_DESCRIPTION":"Autor studuje žurnalistiku na FSV UK. Pravidelně publikuje na Živě.cz, dříve též na serveru SvětNaModro.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"792",
      "s_REAL_NAME":"Schoolnet, European",
      "s_REAL_NAME_REVERS":"European Schoolnet,",
      "s_EMAIL":"brigitte.parry@eun.org",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"956",
      "s_REAL_NAME":"SCIO",
      "s_REAL_NAME_REVERS":"SCIO",
      "s_EMAIL":"mnumerato@scio.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"437",
      "s_REAL_NAME":"Šebor Vít",
      "s_REAL_NAME_REVERS":"Vít Šebor",
      "s_EMAIL":"vit.sebor@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"958",
      "s_REAL_NAME":"Sedlák, Jan ",
      "s_REAL_NAME_REVERS":"Jan Sedlák,",
      "s_EMAIL":"jan.sedlak@cpress.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"964",
      "s_REAL_NAME":"Šeďová Klára",
      "s_REAL_NAME_REVERS":"Klára Šeďová",
      "s_EMAIL":"sedova@phil.muni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"657",
      "s_REAL_NAME":"Seidlová Jana",
      "s_REAL_NAME_REVERS":"Jana Seidlová",
      "s_EMAIL":"jana.seidlova@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"622",
      "s_REAL_NAME":"Sekce SIPVZ MŠMT",
      "s_REAL_NAME_REVERS":"Sekce SIPVZ MŠMT",
      "s_EMAIL":"infogram@msmt.cz",
      "t_DESCRIPTION":"Autorem článku jsou pracovníci Sekce SIPVZ MŠMT ČR.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"868",
      "s_REAL_NAME":"Šerých, Jakub ",
      "s_REAL_NAME_REVERS":"Jakub Šerých,",
      "s_EMAIL":"serych@panska.cz",
      "t_DESCRIPTION":"Střední průmyslová škola sdělovací techniky, Praha 1, Panská 856\/3",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"846",
      "s_REAL_NAME":"Ševčíková, Barbora",
      "s_REAL_NAME_REVERS":"Barbora Ševčíková,",
      "s_EMAIL":"redakce@ikaros.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"874",
      "s_REAL_NAME":"Shahin, Kussai ",
      "s_REAL_NAME_REVERS":"Kussai Shahin,",
      "s_EMAIL":"kussai.shahin@aster.it",
      "t_DESCRIPTION":"Project Manager, ASTER S. Cons. p. a.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"872",
      "s_REAL_NAME":"Šíbová, Marta ",
      "s_REAL_NAME_REVERS":"Marta Šíbová,",
      "s_EMAIL":"sibova@vuppraha.cz",
      "t_DESCRIPTION":"Oddělení základního vzdělávání VÚP Praha",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"431",
      "s_REAL_NAME":"Sichrovský Marek",
      "s_REAL_NAME_REVERS":"Marek Sichrovský",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"993",
      "s_REAL_NAME":"Šikula, Martin",
      "s_REAL_NAME_REVERS":"Martin Šikula,",
      "s_EMAIL":"msikula@1zdar.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"464",
      "s_REAL_NAME":"Šilha Josef",
      "s_REAL_NAME_REVERS":"Josef Šilha",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"674",
      "s_REAL_NAME":"Šilhánová Libuše",
      "s_REAL_NAME_REVERS":"Libuše Šilhánová",
      "s_EMAIL":"sekr@helcom.cz",
      "t_DESCRIPTION":"PhDr. Libuše Šilhánová, CSc., je bývalá mluvčí Charty 77, nyní členka předsednictva Českého helsinského výboru, Jelení 5, 118 00 Praha 1.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"854",
      "s_REAL_NAME":"Šima, Petr",
      "s_REAL_NAME_REVERS":"Petr Šima,",
      "s_EMAIL":"Sima@marketka.vsps-su.cz",
      "t_DESCRIPTION":"ICT koordinátor VOŠ a SPŠ Šumperk",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"729",
      "s_REAL_NAME":"Šimák Miroslav",
      "s_REAL_NAME_REVERS":"Miroslav Šimák",
      "s_EMAIL":"M.Simak@seznam.cz",
      "t_DESCRIPTION":"ZŠ Postřelmov",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"822",
      "s_REAL_NAME":"Šín, Martin",
      "s_REAL_NAME_REVERS":"Martin Šín,",
      "s_EMAIL":"martin.sin@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"736",
      "s_REAL_NAME":"Singr Michal",
      "s_REAL_NAME_REVERS":"Michal Singr",
      "s_EMAIL":"michal@singr.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"912",
      "s_REAL_NAME":"Šíp, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Šíp,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Učitel angličtiny na střední škole",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"584",
      "s_REAL_NAME":"Šiška Viktor ",
      "s_REAL_NAME_REVERS":"Viktor Šiška",
      "s_EMAIL":"siska@zskomdva.zlinedu.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"59",
      "s_REAL_NAME":"Škárka Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Škárka",
      "s_EMAIL":"skarka@cpress.cz",
      "t_DESCRIPTION":"Mgr. Jaroslav Škárka vystudoval pedagogiku na FF MU, v letech 1990 - 1995 působil jako učitel na ZUŠ a gymnáziu. Od roku 1996 pracuje v jako \nredaktor učebnic.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"666",
      "s_REAL_NAME":"SKAV",
      "s_REAL_NAME_REVERS":"SKAV",
      "s_EMAIL":"redakce@ucitelske-listy.cz",
      "t_DESCRIPTION":"Stálé konferenci asociací ve vzdělávání.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"789",
      "s_REAL_NAME":"Skolková, Linda",
      "s_REAL_NAME_REVERS":"Linda Skolková,",
      "s_EMAIL":"skolkova@ikaros.cz",
      "t_DESCRIPTION":"Ústav informačních studií a knihovnictví FF UK v Praze",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"662",
      "s_REAL_NAME":"Skoupá Anna",
      "s_REAL_NAME_REVERS":"Anna Skoupá",
      "s_EMAIL":"skoupa@sssbrno.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"560",
      "s_REAL_NAME":"Škovronek Dalibor",
      "s_REAL_NAME_REVERS":"Dalibor Škovronek",
      "s_EMAIL":"info@acol.cz",
      "t_DESCRIPTION":"Autor je výrobním ředitelem společnosti AutoCont On Line, a.s.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"382",
      "s_REAL_NAME":"Škrabalová Eva",
      "s_REAL_NAME_REVERS":"Eva Škrabalová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"404",
      "s_REAL_NAME":"Škvařil Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Škvařil",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"516",
      "s_REAL_NAME":"Šlancarová Dana",
      "s_REAL_NAME_REVERS":"Dana Šlancarová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"732",
      "s_REAL_NAME":"Slawinská Marta ",
      "s_REAL_NAME_REVERS":"Marta Slawinská",
      "s_EMAIL":"marta.slawinska@gym-orlova.cz",
      "t_DESCRIPTION":"Gymnázium a SOŠ Orlová-Lutyně\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"726",
      "s_REAL_NAME":"Šmída, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Šmída,",
      "s_EMAIL":"jiri.smida@vslib.cz",
      "t_DESCRIPTION":"Technická univerzita v Liberci, Fakulta pedagogická, katedra geografie, Hálkova 6, Liberec 460 01",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"791",
      "s_REAL_NAME":"Šmídová, Lucie",
      "s_REAL_NAME_REVERS":"Lucie Šmídová,",
      "s_EMAIL":"lucie.smidova@post.cz",
      "t_DESCRIPTION":"Ústav informačních studií a knihovnictví FF UK",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"690",
      "s_REAL_NAME":"Šmilauer Václav",
      "s_REAL_NAME_REVERS":"Václav Šmilauer",
      "s_EMAIL":"smilauer@arcig.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"417",
      "s_REAL_NAME":"Smolejová Alena",
      "s_REAL_NAME_REVERS":"Alena Smolejová",
      "s_EMAIL":"smolejova@soubce.cz",
      "t_DESCRIPTION":"PhDr. Alena Smolejová vyučuje na středním odborném učilišti a na střední soukromé škole. Současně působí i jako výchovná poradkyně.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"810",
      "s_REAL_NAME":"Smolíková, Kateřina ",
      "s_REAL_NAME_REVERS":"Kateřina Smolíková,",
      "s_EMAIL":"smolikova@vuppraha.cz",
      "t_DESCRIPTION":"Výzkumný ústav pedagogický v Praze, 1. výzkumná skupina - pedagogika a didaktika všeobecného vzdělávání",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"647",
      "s_REAL_NAME":"Smrčka František",
      "s_REAL_NAME_REVERS":"František Smrčka",
      "s_EMAIL":"smrcka@vosji.cz",
      "t_DESCRIPTION":"PaedDr. František Smrčka vyučuje na Vyšší odborné škole v Jihlavě. ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"57",
      "s_REAL_NAME":"Smutná Jana",
      "s_REAL_NAME_REVERS":"Jana Smutná",
      "s_EMAIL":"jana.smutna@brno.rsd.cz",
      "t_DESCRIPTION":"Jana Smutná (*1966), studovala Vysoké učení technické v Brně, fakultu stavební. V době\nstudia absolvovala kurz pedagogického minima. Vyučovala v počítačových kursech a na střední odborné technické škole.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"786",
      "s_REAL_NAME":"Šnajdrová Marcela ",
      "s_REAL_NAME_REVERS":"Marcela Šnajdrová",
      "s_EMAIL":"snajdrova@vuppraha.cz",
      "t_DESCRIPTION":"Pracuje ve VÚP v Praze, odd. speciálního vzdělávání - specifické poruchy učení a chování, logopedie ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"544",
      "s_REAL_NAME":"Sodomka Petr",
      "s_REAL_NAME_REVERS":"Petr Sodomka",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"812",
      "s_REAL_NAME":"Sotolář, Jiří ",
      "s_REAL_NAME_REVERS":"Jiří Sotolář,",
      "s_EMAIL":"jiri.sotolar@deviceglobal.com",
      "t_DESCRIPTION":"Ředitel Device Automation Czech, spol. s r.o.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"701",
      "s_REAL_NAME":"Šotolová Marie",
      "s_REAL_NAME_REVERS":"Marie Šotolová",
      "s_EMAIL":"marie.sotolova@post.cz",
      "t_DESCRIPTION":"Autorka je volnou novinářkou.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"403",
      "s_REAL_NAME":"Souček Kamil",
      "s_REAL_NAME_REVERS":"Kamil Souček",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"435",
      "s_REAL_NAME":"Špačková Renata",
      "s_REAL_NAME_REVERS":"Renata Špačková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Autorka působí na MŠ Trnava u Třebíče.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"381",
      "s_REAL_NAME":"Spálená Johanka",
      "s_REAL_NAME_REVERS":"Johanka Spálená",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"709",
      "s_REAL_NAME":"Spěváčková Lucie",
      "s_REAL_NAME_REVERS":"Lucie Spěváčková",
      "s_EMAIL":"spevackova@vuppraha.cz",
      "t_DESCRIPTION":"Autorka je pracovnicí VUP Praha.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"658",
      "s_REAL_NAME":"Spilková Vladimíra",
      "s_REAL_NAME_REVERS":"Vladimíra Spilková",
      "s_EMAIL":"vladimira.spilkova@pedf.cuni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"913",
      "s_REAL_NAME":"spomocník, Učitelský ",
      "s_REAL_NAME_REVERS":"Učitelský spomocník,",
      "s_EMAIL":"spomoc@it.pedf.cuni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"869",
      "s_REAL_NAME":"Šrámek, Milan",
      "s_REAL_NAME_REVERS":"Milan Šrámek,",
      "s_EMAIL":"heureka.zlin@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"579",
      "s_REAL_NAME":"Štaffová Irena ",
      "s_REAL_NAME_REVERS":"Irena Štaffová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"559",
      "s_REAL_NAME":"Staník Jan",
      "s_REAL_NAME_REVERS":"Jan Staník",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"učitel matematematiky a zeměpisu na základní škole",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"605",
      "s_REAL_NAME":"Stanislav Martin ",
      "s_REAL_NAME_REVERS":"Martin Stanislav",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"470",
      "s_REAL_NAME":"Štech Stanislav",
      "s_REAL_NAME_REVERS":"Stanislav Štech",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Autor je vedoucím katedry pedagogické a školní psychologie PedF UK Praha.\n\n\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"755",
      "s_REAL_NAME":"Štědroň, Bohumír JUDr. ",
      "s_REAL_NAME_REVERS":"Štědroň, Bohumír JUDr.",
      "s_EMAIL":"info@oss.cz",
      "t_DESCRIPTION":"Místopředseda OSS Aliance pro právo",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"536",
      "s_REAL_NAME":"Šteffl Ondřej",
      "s_REAL_NAME_REVERS":"Ondřej Šteffl",
      "s_EMAIL":"steffl@scio.cz",
      "t_DESCRIPTION":"Autor je ředitelem agentury www.scio.cz, s.r.o.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"750",
      "s_REAL_NAME":"Stehlíková, Monika",
      "s_REAL_NAME_REVERS":"Monika Stehlíková,",
      "s_EMAIL":"Stehlikova.Monika@seznam.cz",
      "t_DESCRIPTION":"Učí na Škole mezinárodních a veřejných vztahů Praha.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"396",
      "s_REAL_NAME":"Stehnová Markéta",
      "s_REAL_NAME_REVERS":"Markéta Stehnová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"728",
      "s_REAL_NAME":"Štěpán Jiří",
      "s_REAL_NAME_REVERS":"Jiří Štěpán",
      "s_EMAIL":"ji.stepan@seznam.cz",
      "t_DESCRIPTION":"Základní škola Kopřivnice, Alšova 1123, 74 221 Kopřivnice",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"608",
      "s_REAL_NAME":"Štěpán Radek ",
      "s_REAL_NAME_REVERS":"Radek Štěpán",
      "s_EMAIL":"radek.mail@seznam.cz",
      "t_DESCRIPTION":"Autor je studentem gymnázia F.X. Šaldy v Liberci.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"842",
      "s_REAL_NAME":"STIC",
      "s_REAL_NAME_REVERS":"STIC",
      "s_EMAIL":"info@stic.cz",
      "t_DESCRIPTION":"School technology innovation center",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"922",
      "s_REAL_NAME":"Stojan, Mojmír",
      "s_REAL_NAME_REVERS":"Mojmír Stojan,",
      "s_EMAIL":"stojan@mail.muni.cz ",
      "t_DESCRIPTION":"Pracoviště:\nKatedra psychologie - Pedagogická fakulta MUNI\nKatedra didaktických technologií - Pedagogická fakulta MUNI",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"468",
      "s_REAL_NAME":"Stoličný Peter",
      "s_REAL_NAME_REVERS":"Peter Stoličný",
      "s_EMAIL":"stolicny@jumbo.ped.muni.cz",
      "t_DESCRIPTION":"Dr. Peter Stoličný působí na Pedagogické fakultě MU.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"499",
      "s_REAL_NAME":"Stopa Pavel",
      "s_REAL_NAME_REVERS":"Pavel Stopa",
      "s_EMAIL":"100pa@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"982",
      "s_REAL_NAME":"Štorm, František",
      "s_REAL_NAME_REVERS":"František Štorm,",
      "s_EMAIL":"mail@stormtype.com",
      "t_DESCRIPTION":"* 3. 7. 1966 v Praze. Studoval na VŠUP v Praze (1985–91). V roce 1993 založil Střešovickou písmolijnu pro realizaci vlastních návrhů písem i historických abeced významných českých písmařů. Zabývá se knižní úpravou, grafickým designem, fotografií a volnou grafikou, spolupracuje na písmových realizacích v architektuře. Od roku 2003 do r. 2007 vedl ateliér písma a typografie na VŠUP v Praze. Za své návrhy písem získal několik zahraničních i domácích ocenění, např. TDC Certificate of Excellence in Typography 2000 (za písmo Biblon ITC), BukvaRaz! Award, Moskva (2001) TDC Certificate of Excellence in Type\nDesign 2008. www.stormtype.com",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"928",
      "s_REAL_NAME":"Strádal, Jiří ",
      "s_REAL_NAME_REVERS":"Jiří Strádal,",
      "s_EMAIL":"stradal@bohem-net.cz",
      "t_DESCRIPTION":"Hlavní manažer projektu Národní soustava kvalifikací, NÚOV",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"600",
      "s_REAL_NAME":"Straka Pavel ",
      "s_REAL_NAME_REVERS":"Pavel Straka",
      "s_EMAIL":"p.straka@zshtyn.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"650",
      "s_REAL_NAME":"Straková Jana",
      "s_REAL_NAME_REVERS":"Jana Straková",
      "s_EMAIL":"xstrakovaj@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"424",
      "s_REAL_NAME":"Stránský Václav",
      "s_REAL_NAME_REVERS":"Václav Stránský",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"autor působí v oblasti speciálního školství",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"427",
      "s_REAL_NAME":"Strejčková Ludmila",
      "s_REAL_NAME_REVERS":"Ludmila Strejčková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Mgr. Ludmila Strejčková je speciální pedagožka. Vyučuje angličtinu ve 4. a 5. ročníku speciální základní školy a současně působí ve speciálně pedagogickém centru.\n\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"575",
      "s_REAL_NAME":"Střeštík Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Střeštík",
      "s_EMAIL":"jsi@jsi.cz",
      "t_DESCRIPTION":"Jaroslav Střeštík je pedagog a člen Jednoty školských informatiků.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"527",
      "s_REAL_NAME":"Strnad Jiří",
      "s_REAL_NAME_REVERS":"Jiří Strnad",
      "s_EMAIL":"strnad@issecv.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"634",
      "s_REAL_NAME":"Štursa Pavel",
      "s_REAL_NAME_REVERS":"Pavel Štursa",
      "s_EMAIL":"stursa@pf.jcu.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"870",
      "s_REAL_NAME":"Stýblová Hana",
      "s_REAL_NAME_REVERS":"Hana Stýblová",
      "s_EMAIL":"zs.bozkov@volny.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"389",
      "s_REAL_NAME":"Suchá Tereza",
      "s_REAL_NAME_REVERS":"Tereza Suchá",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"653",
      "s_REAL_NAME":"Suchánková Helena ",
      "s_REAL_NAME_REVERS":"Helena Suchánková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Mgr. Helena Suchánková pracuje jako učitelka německého jazyka na ZŠ Táborská, Praha-Nusle.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"599",
      "s_REAL_NAME":"Suchánková Věra",
      "s_REAL_NAME_REVERS":"Věra Suchánková",
      "s_EMAIL":"suchanko@it.pedf.cuni.cz",
      "t_DESCRIPTION":"RNDr. Věra Suchánková působí na Katedře informačních technologií a technické výchovy PedF UK v Praze.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"450",
      "s_REAL_NAME":"Suchoradský Oldřich",
      "s_REAL_NAME_REVERS":"Oldřich Suchoradský",
      "s_EMAIL":"zs.kopidlno@quick.cz",
      "t_DESCRIPTION":"Oldřich Suchoradský je učitelem na ZŠ Kopidlno.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"626",
      "s_REAL_NAME":"Šulcová Renata ",
      "s_REAL_NAME_REVERS":"Renata Šulcová",
      "s_EMAIL":"rena@natur.cuni.cz",
      "t_DESCRIPTION":"RNDr. Renata Šulcová působí na Přírodovědecké fakultě Univerzity Karlovy.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"947",
      "s_REAL_NAME":"Šulcová, Jitka ",
      "s_REAL_NAME_REVERS":"Jitka Šulcová,",
      "s_EMAIL":"sulcova.jitka@cmkos.cz",
      "t_DESCRIPTION":"Právník ČMOS PŠ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"598",
      "s_REAL_NAME":"Sumbal Jiří ",
      "s_REAL_NAME_REVERS":"Jiří Sumbal",
      "s_EMAIL":"sumbal@zsals.edunet.cz",
      "t_DESCRIPTION":"Autor vyučuje na ZŠ Kopřivnice a je spolupracovníkem firmy SGP (Baltík, Baltazar).",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"1001",
      "s_REAL_NAME":"Švarc, Petr",
      "s_REAL_NAME_REVERS":"Petr Švarc,",
      "s_EMAIL":"reditelstvi@gymrumburk.cz",
      "t_DESCRIPTION":"Pedagog Gymnázia Rumburk",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"667",
      "s_REAL_NAME":"Svaz měst a obcí ČR",
      "s_REAL_NAME_REVERS":"Svaz měst a obcí ČR",
      "s_EMAIL":"smocr@smocr.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"673",
      "s_REAL_NAME":"Svoboda Jindřich",
      "s_REAL_NAME_REVERS":"Jindřich Svoboda",
      "s_EMAIL":"jindrasvoboda@volny.cz",
      "t_DESCRIPTION":"Autor vyučuje na gymnáziu Vídeňská v Brně.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"429",
      "s_REAL_NAME":"Svobodová Jana",
      "s_REAL_NAME_REVERS":"Jana Svobodová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"doc. PhDr. Jana Svobodová, CSc. působí na Pedagogické fakultě Ostravské univerzity. \n\n\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"713",
      "s_REAL_NAME":"Svobodová Jitka",
      "s_REAL_NAME_REVERS":"Jitka Svobodová",
      "s_EMAIL":"gy_svobodova@supce.cz",
      "t_DESCRIPTION":"Gymnázium Pardubice",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"727",
      "s_REAL_NAME":"Sýkora Dan",
      "s_REAL_NAME_REVERS":"Dan Sýkora",
      "s_EMAIL":"delta.soft@bluetone.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"754",
      "s_REAL_NAME":"Sýkora, Stanislav",
      "s_REAL_NAME_REVERS":"Stanislav Sýkora,",
      "s_EMAIL":"66488@mail.muni.cz",
      "t_DESCRIPTION":"studující Filozofická fakulty Masarykovy univerzity v Brně",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"632",
      "s_REAL_NAME":"Táborský Pavel ",
      "s_REAL_NAME_REVERS":"Pavel Táborský",
      "s_EMAIL":"taborsky.pavel@tiscali.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"800",
      "s_REAL_NAME":"Taibr, Pavel",
      "s_REAL_NAME_REVERS":"Pavel Taibr,",
      "s_EMAIL":"taibr@atlas.cz",
      "t_DESCRIPTION":"Gymnázium F.X.Šaldy v Liberci",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"963",
      "s_REAL_NAME":"TASR",
      "s_REAL_NAME_REVERS":"TASR",
      "s_EMAIL":"domred@tasr.sk",
      "t_DESCRIPTION":"Tlačová agentúra Slovenskej republiky – Slovakia",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"784",
      "s_REAL_NAME":"test",
      "s_REAL_NAME_REVERS":"test",
      "s_EMAIL":"test@test.cz",
      "t_DESCRIPTION":"test",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"770",
      "s_REAL_NAME":"Thomitzková, Emilie ",
      "s_REAL_NAME_REVERS":"Emilie Thomitzková,",
      "s_EMAIL":"emilie.thomi@seznam.cz",
      "t_DESCRIPTION":"Vystudovala Pedagogickou fakultu v Ostravě, obor čeština - výtvarná výchova. Od roku 1979 se s přestávkami věnuje pedagogické činnosti jako učitelka na základní škole.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"454",
      "s_REAL_NAME":"tisková agentura Dětská",
      "s_REAL_NAME_REVERS":"tisková agentura Dětská",
      "s_EMAIL":"dta@cmail.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"734",
      "s_REAL_NAME":"Tomáš Hudec a kolektiv,",
      "s_REAL_NAME_REVERS":"Tomáš Hudec a kolektiv,",
      "s_EMAIL":"hudec.t@gym-bohumin.cz",
      "t_DESCRIPTION":"Gymnázium Františka Živného Bohumín",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"495",
      "s_REAL_NAME":"Tomáš Komrska, Miloš Randula Bohuslav Cháb,",
      "s_REAL_NAME_REVERS":"Tomáš Komrska, Miloš Randula Bohuslav Cháb,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"939",
      "s_REAL_NAME":"Tomek, Karel",
      "s_REAL_NAME_REVERS":"Karel Tomek,",
      "s_EMAIL":"tomek.trebic@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"861",
      "s_REAL_NAME":"Trnková, Kateřina",
      "s_REAL_NAME_REVERS":"Kateřina Trnková,",
      "s_EMAIL":"trnkova@phil.muni.cz",
      "t_DESCRIPTION":"Ústav pedagogických věd, Filozofická fakulta, Masarykova univerzita, A. Nováka 1, 602 00 Brno",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"763",
      "s_REAL_NAME":"Tůma, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Tůma,",
      "s_EMAIL":"tuma@karlin.mff.cuni.cz",
      "t_DESCRIPTION":"Vedoucí Katedry algebry na MFF UK v Praze",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"859",
      "s_REAL_NAME":"Tupý, Jan",
      "s_REAL_NAME_REVERS":"Jan Tupý,",
      "s_EMAIL":"tupy@vuppraha.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"24",
      "s_REAL_NAME":"Týden Časopis",
      "s_REAL_NAME_REVERS":"Časopis Týden",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"829",
      "s_REAL_NAME":"Týdeník-školství",
      "s_REAL_NAME_REVERS":"Týdeník-školství",
      "s_EMAIL":"tondlova@tydenik-skolstvi.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"398",
      "s_REAL_NAME":"Tyl Jiří",
      "s_REAL_NAME_REVERS":"Jiří Tyl",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"998",
      "s_REAL_NAME":"učitel, Moderní",
      "s_REAL_NAME_REVERS":"Moderní učitel,",
      "s_EMAIL":" info@modernivyuka.cz",
      "t_DESCRIPTION":"Tato sekce portálu Microsoft PArtneři ve vzdělávání \"Moderní Výuka\" je určena všem pedagogickým pracovníkům se zájmem o využívání prvků informačních a komunikačních technologií při práci se svými žáky a studenty. V rámci této sekce naleznete širokou škálu článků, metodických návodů, myšlenek a nápadů, které mají jednotný cíl - podpořit efektivní využívání ICT ze stranky pedagogických pracovníků.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"780",
      "s_REAL_NAME":"Uhlíř, Aleš",
      "s_REAL_NAME_REVERS":"Aleš Uhlíř,",
      "s_EMAIL":"alesuhlir@quick.cz",
      "t_DESCRIPTION":"Právník ve Frýdku-Místku.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"794",
      "s_REAL_NAME":"ÚIV",
      "s_REAL_NAME_REVERS":"ÚIV",
      "s_EMAIL":"info@uiv.cz",
      "t_DESCRIPTION":"Ústav pro informace ve vzdělávání",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"718",
      "s_REAL_NAME":"Úlovec, Roman",
      "s_REAL_NAME_REVERS":"Roman Úlovec,",
      "s_EMAIL":"ulovec@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"883",
      "s_REAL_NAME":"ÚOOÚ",
      "s_REAL_NAME_REVERS":"ÚOOÚ",
      "s_EMAIL":"info@uoou.cz",
      "t_DESCRIPTION":"Úřad pro ochranu osobních údajů, Pplk. Sochora 27, 170 00 Praha 7",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"526",
      "s_REAL_NAME":"Václavík Vladimír",
      "s_REAL_NAME_REVERS":"Vladimír Václavík",
      "s_EMAIL":"vladimir.vaclavik@uhk.cz",
      "t_DESCRIPTION":"Autor působí na Pedagogické fakultě Univerzity Hradec Králové.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"984",
      "s_REAL_NAME":"Václavík, Marek",
      "s_REAL_NAME_REVERS":"Marek Václavík,",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"466",
      "s_REAL_NAME":"Vaculová Jana",
      "s_REAL_NAME_REVERS":"Jana Vaculová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"858",
      "s_REAL_NAME":"Vacušková Marta",
      "s_REAL_NAME_REVERS":"Marta Vacušková",
      "s_EMAIL":"sekretariat@etickeforumcr.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"887",
      "s_REAL_NAME":"Valenta, Josef ",
      "s_REAL_NAME_REVERS":"Josef Valenta,",
      "s_EMAIL":"editor@rvp.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"895",
      "s_REAL_NAME":"Vančát, Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Vančát,",
      "s_EMAIL":"info@eduart.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"758",
      "s_REAL_NAME":"Vaněk, Vladimír PaedDr. CSc. ",
      "s_REAL_NAME_REVERS":"Vaněk, Vladimír PaedDr. CSc.",
      "s_EMAIL":"vladimir.vanek@osu.cz",
      "t_DESCRIPTION":"Odborný asistent katedry technické a pracovní výchovy pedagogické fakulty Ostravské university.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"841",
      "s_REAL_NAME":"Vaníček Jiří",
      "s_REAL_NAME_REVERS":"Jiří Vaníček",
      "s_EMAIL":"vanicek@pf.jcu.cz",
      "t_DESCRIPTION":"Autor působí na katedře informatiky Pedagogické fakulty Jihočeské univerzity v Českých Budějovicích.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"1000",
      "s_REAL_NAME":"Vaníčková, Michaela",
      "s_REAL_NAME_REVERS":"Michaela Vaníčková,",
      "s_EMAIL":"Vanickova.Michaela@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"482",
      "s_REAL_NAME":"Vanický Petr",
      "s_REAL_NAME_REVERS":"Petr Vanický",
      "s_EMAIL":"vande@gyzamb.cz",
      "t_DESCRIPTION":"Autor vyučuje na gymnáziu v Žamberku.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"757",
      "s_REAL_NAME":"Vaňková, Hana PaedDr. CSc. ",
      "s_REAL_NAME_REVERS":"Vaňková, Hana PaedDr. CSc.",
      "s_EMAIL":"hana.vankova@osu.cz",
      "t_DESCRIPTION":"Odborná asistentka katedry technické a pracovní výchovy pedagogické fakulty Ostravské university.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"830",
      "s_REAL_NAME":"Varianty",
      "s_REAL_NAME_REVERS":"Varianty",
      "s_EMAIL":"vaclav.zeman@clovekvtisni.cz",
      "t_DESCRIPTION":"Vzdělávací program Varianty společnosti Člověk v tísni je zaměřen na zavádění interkulturního vzdělávání (IKV) a globální rozvojové výchovy (GRV) do českého školství. Jedná se o tematické oblasti, jejichž přítomnost ve výuce vyžadují existující či vznikající kurikulární dokumenty českého školství, ale jejichž praktické zastoupení v hodinách je stále ještě nedostatečné. Témata IKV a GRV v praxi překračují oblast školství a jsou aktuální i pro další profesní skupiny.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"698",
      "s_REAL_NAME":"Vašťatková Jana",
      "s_REAL_NAME_REVERS":"Jana Vašťatková",
      "s_EMAIL":"vastatko@pdfnw.upol.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"877",
      "s_REAL_NAME":"Vašutová, Jaroslava ",
      "s_REAL_NAME_REVERS":"Jaroslava Vašutová,",
      "s_EMAIL":"jaroslava.vasutova@pedf.cuni.cz",
      "t_DESCRIPTION":"Zástupkyně ředitelky ÚVRŠ, vedoucí KME, Pedagogická fakulta UK",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"629",
      "s_REAL_NAME":"Verner Jiří",
      "s_REAL_NAME_REVERS":"Jiří Verner",
      "s_EMAIL":"jverner@czesha.cz",
      "t_DESCRIPTION":"Autor je ICT koordinátorem Unie školských asociací ČR - CZESHA, přidruženým členem Jednoty školských informatiků a podílí se na řadě projektů v oblasti zavádění informačních technologií do vzdělávání. Po dobu trvání projektu IT2005 je jeho mediálním mluvčím.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"43",
      "s_REAL_NAME":"Veselá Hana",
      "s_REAL_NAME_REVERS":"Hana Veselá",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"405",
      "s_REAL_NAME":"Veselík Patrik",
      "s_REAL_NAME_REVERS":"Patrik Veselík",
      "s_EMAIL":"patrik.veselik@cpress.cz",
      "t_DESCRIPTION":"Autor je redaktorem internetového magazínu Živě.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"476",
      "s_REAL_NAME":"Veselý Marek",
      "s_REAL_NAME_REVERS":"Marek Veselý",
      "s_EMAIL":"vesely.marek@seznam.cz",
      "t_DESCRIPTION":"Marek Veselý vyučuje na ZŠ a MŠ Kladno, Vodárenská 2115.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"459",
      "s_REAL_NAME":"Veselý Vladimír",
      "s_REAL_NAME_REVERS":"Vladimír Veselý",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"793",
      "s_REAL_NAME":"Větvička, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Větvička,",
      "s_EMAIL":"info@kyberpunk.org",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"19",
      "s_REAL_NAME":"Viduna Igor",
      "s_REAL_NAME_REVERS":"Igor Viduna",
      "s_EMAIL":"rogirogi@post.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"890",
      "s_REAL_NAME":"Vinšová Hana",
      "s_REAL_NAME_REVERS":"Hana Vinšová",
      "s_EMAIL":"vinsova@vuppraha.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"744",
      "s_REAL_NAME":"Vít, Svatopluk",
      "s_REAL_NAME_REVERS":"Svatopluk Vít,",
      "s_EMAIL":"svatopluk.vit@quick.cz",
      "t_DESCRIPTION":"Počítačový samouk, momentálně\nvšak zaměstnán jako správce sítě. Hlavní pracovní náplní je práce ve\nMS Windows a příprava uživatelských školení, doma však s úspěchem\npoužívá Linux. Baví ho práce s multiplatformními produkty jako je\nOpenOffice.org, GIMP, DIA či Inkscape a svět Open Source všeobecně. Informace o autorovi naleznete v jeho <A HREF=\"http:\/\/www.joomlaportal.cz\/content\/view\/135\/2\/\">medailonku<\/A>.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"991",
      "s_REAL_NAME":"Vlasák, Martin",
      "s_REAL_NAME_REVERS":"Martin Vlasák,",
      "s_EMAIL":"vlasak.mar@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"490",
      "s_REAL_NAME":"Vlášek Josef",
      "s_REAL_NAME_REVERS":"Josef Vlášek",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"771",
      "s_REAL_NAME":"Vochocová, Lenka",
      "s_REAL_NAME_REVERS":"Lenka Vochocová,",
      "s_EMAIL":"info@zabanaprameni.cz",
      "t_DESCRIPTION":"Interní doktorandka oboru mediální studia Fakulty sociálních věd Univerzity Karlovy (FSV UK)",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"817",
      "s_REAL_NAME":"Vojnar, Petr",
      "s_REAL_NAME_REVERS":"Petr Vojnar,",
      "s_EMAIL":"vojnarp@phoenix.inf.upol.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"419",
      "s_REAL_NAME":"Vojtová Veronika",
      "s_REAL_NAME_REVERS":"Veronika Vojtová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":"Veronika Vojtová působí jako sociální pedagog a poradce se 7 lety praxe v oblasti drogových závislostí. V současné době zaměstnaná ve Sdružení Podané ruce v centru primární a sekundární prevence.",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"775",
      "s_REAL_NAME":"Vondrová, Petra",
      "s_REAL_NAME_REVERS":"Petra Vondrová,",
      "s_EMAIL":"redakce@ceskaskola.cz",
      "t_DESCRIPTION":"Autorka je odbornicí v oblasti pedagogiky a výtvarné výchovy pro předškolní děti a žáky prvního stupně základní školy. Vystudovala Pedagogickou fakultu Masarykovy univerzity v Brně, obor český jazyk a výtvarná výchova. Dlouhodobě se zabývá problematikou současného výtvarného umění a jeho přiblížení se nejmladším dětem, didaktikou a metodikou výtvarné výchovy, vývojem dětské kresby. Svou pozornost věnuje také beletrii pro děti.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"847",
      "s_REAL_NAME":"Vorlíčková, Blanka",
      "s_REAL_NAME_REVERS":"Blanka Vorlíčková,",
      "s_EMAIL":"redakce@ikaros.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"614",
      "s_REAL_NAME":"Votruba Václav",
      "s_REAL_NAME_REVERS":"Václav Votruba",
      "s_EMAIL":"v.votruba@zspalmovka.cz",
      "t_DESCRIPTION":"Autor vyučuje na ZŠ Palmovka v Praze.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"954",
      "s_REAL_NAME":"Votruba, Václav ",
      "s_REAL_NAME_REVERS":"Václav Votruba,",
      "s_EMAIL":"vvt3bcd@post.cz",
      "t_DESCRIPTION":"Učitel na OA",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"612",
      "s_REAL_NAME":"Vrzáček Petr",
      "s_REAL_NAME_REVERS":"Petr Vrzáček",
      "s_EMAIL":"petr.vrzacek@osf.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"806",
      "s_REAL_NAME":"VÚP",
      "s_REAL_NAME_REVERS":"VÚP",
      "s_EMAIL":"info@vuppraha.cz",
      "t_DESCRIPTION":"Výzkumný ústav pedagogický v Praze",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"384",
      "s_REAL_NAME":"Vykoukalová Zdeňka",
      "s_REAL_NAME_REVERS":"Zdeňka Vykoukalová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"630",
      "s_REAL_NAME":"Vyoral Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Vyoral",
      "s_EMAIL":"jaroslav.vyoral@cpress.cz",
      "t_DESCRIPTION":"Autor je redaktorem časopisu Computer.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"743",
      "s_REAL_NAME":"Vyskoč, Jozef",
      "s_REAL_NAME_REVERS":"Jozef Vyskoč,",
      "s_EMAIL":"jozef@vaf.sk",
      "t_DESCRIPTION":"Živí sa poradenstvom v oblasti bezpečnosti informačných systémov. Pravidelný prispievateľ do patavedeckých seminárov v Bratislave. Prednáša (informačnú bezpečnosť, čo iné) na UK v Bratislave a Univerzite sv. Cyrila a Metoda v Trnave. Ďalšie informácie o ňom možno nájsť na <A HREF=\"http:\/\/www.vaf.sk\/tim.htm\">www.vaf.sk\/tim.htm<\/A>.",
      "s_PHOTO_NAME":"VyskocJozef.jpg",
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"40",
      "s_REAL_NAME":"vyučování Moderní",
      "s_REAL_NAME_REVERS":"Moderní vyučování",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"936",
      "s_REAL_NAME":"Wachtl, Zdeněk",
      "s_REAL_NAME_REVERS":"Zdeněk Wachtl,",
      "s_EMAIL":"webmaster@hance.cz",
      "t_DESCRIPTION":"Pedagog v aktivní službě, introvert se sklony k melancholii, krátce a výstižně - nihilisticko-šovinistický rododendronik.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"543",
      "s_REAL_NAME":"Wagner Jan",
      "s_REAL_NAME_REVERS":"Jan Wagner",
      "s_EMAIL":"jan.wagner@cpress.cz",
      "t_DESCRIPTION":"Publicista, ICT konsultant a pedagog. Publikoval od roku 1994 nejprve v časopisech CHIP, Win, Computer, Connect!, Computer, Profit a dalších. V letech 1998-2001 redaktor Světa Namodro a šéfredaktor několika jeho částí. Na České škole publikuje od poloviny roku 2002, od roku 2006 zde pracuje postupně jako redaktor, výkonný šéfredaktor a nyní jako šéfredaktor. Věnuje se především problematice eLearningu a aplikace ICT ve školství a publikuje na řadě webů či blogů jako jsou <a id=\"e-su\" href=\"http:\/\/www.lupa.cz\/autori\/jan-wagner\/\" class=\"external text\" title=\"http:\/\/www.lupa.cz\/autori\/jan-wagner\/\" rel=\"nofollow\">LUPA<\/a>, <a id=\"e-su0\" href=\"http:\/\/www.zive.cz\/Autori\/sc-44\/default.aspx?author=351&fname=Wagner+Jan\" class=\"external text\" title=\"http:\/\/www.zive.cz\/Autori\/sc-44\/default.aspx?author=351&fname=Wagner+Jan\" rel=\"nofollow\">Živě<\/a>, <a id=\"e-su1\" href=\"http:\/\/www.blisty.cz\/aut\/452\/art.html\" class=\"external text\" title=\"http:\/\/www.blisty.cz\/aut\/452\/art.html\" rel=\"nofollow\">Britské listy<\/a>, <a id=\"e-su2\" href=\"http:\/\/jankovy.nazory.cz\/\" class=\"external text\" title=\"http:\/\/jankovy.nazory.cz\/\" rel=\"nofollow\">Jankovy názory, <\/a><a id=\"e-su3\" href=\"http:\/\/jankuv.blog.lupa.cz\/\" class=\"external text\" title=\"http:\/\/jankuv.blog.lupa.cz\/\" rel=\"nofollow\">Jankův blog.LUPA, <\/a><a id=\"e-su4\" href=\"http:\/\/www.pedagogicke.info\/\" class=\"external text\" title=\"http:\/\/www.pedagogicke.info\/\" rel=\"nofollow\">pedagogicke.info<\/a>, <a title=\"JustIT.cz\" href=\"http:\/\/www.justit.cz\/u.asp?u=1002\" id=\"dgvx\">JustIT.cz<\/a>, <a title=\"blogy GUG.CZ\" href=\"http:\/\/www.gug.cz\" id=\"fogm\">blogy GUG.CZ<\/a> a další.<br id=\"xu_o\">\n<br id=\"bc3l\">\n. \n",
      "s_PHOTO_NAME":"WagnerJan.gif",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"34",
      "s_REAL_NAME":"Wágnerová Valerie",
      "s_REAL_NAME_REVERS":"Valerie Wágnerová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"796",
      "s_REAL_NAME":"Walterová, Eliška",
      "s_REAL_NAME_REVERS":"Eliška Walterová,",
      "s_EMAIL":"eliska.walterova@uvrs.pedf.cuni.cz",
      "t_DESCRIPTION":"Ředitelka Ústavu výzkumu a rozvoje školství Pedagogická fakulty Univerzity Karlovy",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"741",
      "s_REAL_NAME":"WikiBooks",
      "s_REAL_NAME_REVERS":"WikiBooks",
      "s_EMAIL":"jan.wagner@cpbooks.cz",
      "t_DESCRIPTION":"Projekt Wikiknihy si klade za cíl shromažďovat a rozšiřovat svobodné otevřené materiály, manuály, knihy a jiné texty v českám jazyce. ",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"708",
      "s_REAL_NAME":"Winter Jaroslav",
      "s_REAL_NAME_REVERS":"Jaroslav Winter",
      "s_EMAIL":"winter@brezen.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"835",
      "s_REAL_NAME":"Wojnar, Pavel ",
      "s_REAL_NAME_REVERS":"Pavel Wojnar,",
      "s_EMAIL":"pavel.wojnar@mendelova.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"950",
      "s_REAL_NAME":"Zábranský, Tomáš ",
      "s_REAL_NAME_REVERS":"Tomáš Zábranský,",
      "s_EMAIL":"info@adiktologie.cz",
      "t_DESCRIPTION":"Centrum adiktologie",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"588",
      "s_REAL_NAME":"Žáčková Hana",
      "s_REAL_NAME_REVERS":"Hana Žáčková",
      "s_EMAIL":"redakce@ucitelske-listy.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"705",
      "s_REAL_NAME":"Zahradníková Šárka",
      "s_REAL_NAME_REVERS":"Šárka Zahradníková",
      "s_EMAIL":"sarka.zahradnikova@clovekvtisni.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"739",
      "s_REAL_NAME":"Zámečník, Bohumír ",
      "s_REAL_NAME_REVERS":"Bohumír Zámečník,",
      "s_EMAIL":"bohumir.zamecnik@seznam.cz",
      "t_DESCRIPTION":"Studuje Gymnázium Žamberk 1998-2006, po maturitě (2006) plánuje studovat obor Informatika, nejspíš na FEL ČVUT.",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"498",
      "s_REAL_NAME":"Zapletalová Jana",
      "s_REAL_NAME_REVERS":"Jana Zapletalová",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"811",
      "s_REAL_NAME":"Zatloukalová, Daniela",
      "s_REAL_NAME_REVERS":"Daniela Zatloukalová,",
      "s_EMAIL":"dzatloukalova@ssprool.cz",
      "t_DESCRIPTION":"Střední škola polytechnická Olomouc, Rooseveltova 79, 779 00 0lomouc; Tel.: 585 724 216",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"893",
      "s_REAL_NAME":"Zdražil, Tomáš",
      "s_REAL_NAME_REVERS":"Tomáš Zdražil,",
      "s_EMAIL":"tomas.zdrazil@waldorf.semily.cz",
      "t_DESCRIPTION":"Učitel ZŠ waldorfské v Semilech",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"655",
      "s_REAL_NAME":"Zelená Lucie",
      "s_REAL_NAME_REVERS":"Lucie Zelená",
      "s_EMAIL":"lucisz@centrum.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"548",
      "s_REAL_NAME":"Zelený Pavel",
      "s_REAL_NAME_REVERS":"Pavel Zelený",
      "s_EMAIL":"pavel.zeleny@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"50",
      "n_PRICE_1KBCLICKS":"100",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"0",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"686",
      "s_REAL_NAME":"Zelle John  ",
      "s_REAL_NAME_REVERS":"John Zelle",
      "s_EMAIL":"zelle@wartburg.edu",
      "t_DESCRIPTION":"John M. Zelle působí na Katedře matematiky, počítačových věd a fyziky\nUniverzity Wartburg, Waverly, USA.\n",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"513",
      "s_REAL_NAME":"Zemánková Kateřina",
      "s_REAL_NAME_REVERS":"Kateřina Zemánková",
      "s_EMAIL":"info@ceskaskola.cz",
      "t_DESCRIPTION":{
        
      },
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"719",
      "s_REAL_NAME":"Židlická Markéta",
      "s_REAL_NAME_REVERS":"Markéta Židlická",
      "s_EMAIL":"spiralis@spiralis-os.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"765",
      "s_REAL_NAME":"Zíka, Ivan",
      "s_REAL_NAME_REVERS":"Ivan Zíka,",
      "s_EMAIL":"zika_ivan@volny.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"959",
      "s_REAL_NAME":"Živě",
      "s_REAL_NAME_REVERS":"Živě",
      "s_EMAIL":"david.polesny@cpress.cz",
      "t_DESCRIPTION":"Mgazín Živě.cz a časopis Computer",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"997",
      "s_REAL_NAME":"Zlatník, Jiří",
      "s_REAL_NAME_REVERS":"Jiří Zlatník,",
      "s_EMAIL":"zlatnik@gykovy.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"25",
      "s_REAL_NAME":"Zounek Jiří",
      "s_REAL_NAME_REVERS":"Jiří Zounek",
      "s_EMAIL":"zounek@phil.muni.cz",
      "t_DESCRIPTION":"Mgr. Jiří Zounek (1973), absolvent Filozofické fakulty Masarykovy univerzity, obory pedagogika a historie. V září 1994 ukončení kurzu „Podnikové hospodářství a management“, který pořádala švýcarsko-německá vzdělávací nadace. \nV současnosti autor pracuje jako odborný asistent na Ústavu pedagogických věd FF MU. Zaměřuje se vědecky na dějiny českého školství a pedagogiky ve 20. století.  Druhý směr odborného zájmu směřuje k počítačům, Internetu, didaktické technice a jejich využití ve školství. Dále se zajímá o problémy a specifika učitelské profese.\nPublikoval své studie a články např. v Pedagogické orientaci, Časopise Matice moravské, v Universitas a dalších.\n",
      "n_PRICE_1KB":"100",
      "n_PRICE_1KBCLICKS":"150",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"50",
      "n_PRICE_ARTICLE_TIT":"100"
    },
    {
      "pk_tbl_AUTHORS":"795",
      "s_REAL_NAME":"Zounková, Zuzana",
      "s_REAL_NAME_REVERS":"Zuzana Zounková,",
      "s_EMAIL":"ZounkovaZ@seznam.cz",
      "t_DESCRIPTION":{
        
      },
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    },
    {
      "pk_tbl_AUTHORS":"884",
      "s_REAL_NAME":"Žufanová, Hana",
      "s_REAL_NAME_REVERS":"Hana Žufanová,",
      "s_EMAIL":"zufanova@csicr.cz",
      "t_DESCRIPTION":"Česká školní inspekce",
      "s_PHOTO_NAME":{
        
      },
      "n_PRICE_1KB":"0",
      "n_PRICE_1KBCLICKS":"0",
      "n_PRICE_COEFICIENT":"1",
      "n_PRICE_ARTICLE":"300",
      "n_PRICE_ARTICLE_TIT":"0"
    }
  ]
};
